﻿namespace ShopDB
{
}

namespace ShopDB
{


    public partial class ShopDBDataSet
    {
    }
}
