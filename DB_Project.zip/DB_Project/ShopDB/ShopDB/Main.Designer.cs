﻿namespace ShopDB
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabFactors = new System.Windows.Forms.TabPage();
            this.lblAmountAfter_Factor = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblAmount_Factor = new System.Windows.Forms.Label();
            this.lblGoodName_Factor = new System.Windows.Forms.Label();
            this.lblGoodUnitPrice_Factor = new System.Windows.Forms.Label();
            this.lblCustomerPhone_Factor = new System.Windows.Forms.Label();
            this.lblCutomerName_Factor = new System.Windows.Forms.Label();
            this.lblFactorDate_Factor = new System.Windows.Forms.Label();
            this.lblFactorID_Factor = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCountGood_Factor = new System.Windows.Forms.TextBox();
            this.txtDiscount_Factor = new System.Windows.Forms.TextBox();
            this.picGoodTab = new System.Windows.Forms.PictureBox();
            this.picCustomerTab = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnClear_Factor = new System.Windows.Forms.Button();
            this.btnInsertFactorRegister_Factor = new System.Windows.Forms.Button();
            this.btnInsertCart_Factor = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboGoodID_Factor = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboCustomerID_Factor = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewFactor = new System.Windows.Forms.DataGridView();
            this.goodCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AllCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.remove = new System.Windows.Forms.DataGridViewImageColumn();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabGoods = new System.Windows.Forms.TabPage();
            this.dataGridViewGood = new System.Windows.Forms.DataGridView();
            this.btnClear_Good = new System.Windows.Forms.Button();
            this.btnInsertToGoodTab_Good = new System.Windows.Forms.Button();
            this.btnDeleteGood_Good = new System.Windows.Forms.Button();
            this.btnUpdateGood_Good = new System.Windows.Forms.Button();
            this.btnInsertGood_Good = new System.Windows.Forms.Button();
            this.txtGoodStocks_Good = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtGoodUnitPrice_Good = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtGoodName_Good = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtGoodID_Good = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.txtGoodNameSearch_Good = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtGoodIDSearch_Good = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tabCustomers = new System.Windows.Forms.TabPage();
            this.txtNameSearch_Customer = new System.Windows.Forms.TextBox();
            this.txtIDSearch_Customer = new System.Windows.Forms.TextBox();
            this.btnInsertToFactorTab_Customer = new System.Windows.Forms.Button();
            this.txtCustomerBirthday_Customer = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.dataGridViewCustomers_Customer = new System.Windows.Forms.DataGridView();
            this.btnDeleteCustomer_Customer = new System.Windows.Forms.Button();
            this.btnClear_Customer = new System.Windows.Forms.Button();
            this.btnUpdateCustomer_Customer = new System.Windows.Forms.Button();
            this.btnInsertCustomer_Customer = new System.Windows.Forms.Button();
            this.txtCustomerTel_Customer = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtCustomerLName_Customer = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtCustomerFName_Customer = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtCustomerID_Customer = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.tabReports = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabLog = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnClearLog = new System.Windows.Forms.Button();
            this.btnSearchAllLog = new System.Windows.Forms.Button();
            this.txtGoodIdLog = new System.Windows.Forms.TextBox();
            this.txtGoodNameLog = new System.Windows.Forms.TextBox();
            this.btnSearchDateLog = new System.Windows.Forms.Button();
            this.comboActionTypeLog = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtDateEndLog = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtDateStartLog = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.dataGridViewLog = new System.Windows.Forms.DataGridView();
            this.tabFactorTable = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.txtCustomerIdFactorTable = new System.Windows.Forms.TextBox();
            this.txtFactorIdFactorTable = new System.Windows.Forms.TextBox();
            this.btnClearFactorTable = new System.Windows.Forms.Button();
            this.btnSearchAllFactorTable = new System.Windows.Forms.Button();
            this.btnSearchDateFactorTable = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtDateEndFactorTable = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtDateStartFactorTable = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.dataGridViewFactorTable = new System.Windows.Forms.DataGridView();
            this.tabRegisterFactor = new System.Windows.Forms.TabPage();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.btnClearRegisterTable = new System.Windows.Forms.Button();
            this.btnSearchAllRegisterTable = new System.Windows.Forms.Button();
            this.btnSearchOffRegisterTable = new System.Windows.Forms.Button();
            this.txtGoodIdRegisterTable = new System.Windows.Forms.TextBox();
            this.txtFavtorIdRegisterTable = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.txtEndOffRegisterTable = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtStartOffRegisterTable = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.dataGridViewRegisterFactor = new System.Windows.Forms.DataGridView();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.fKFactorCustomersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fKFactorCustomersBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.goodsIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodsNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodsUnitPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodsStockDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shopDBDataSet = new ShopDB.ShopDBDataSet();
            this.customerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerFamilyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerPhoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerBirthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerAgeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idOfGoodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameOfGoodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeOfActionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateOfActionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.logOfGoodsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.factorIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coustomerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.factorDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.factorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.factorIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodsIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.discountValueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountAfterDiscountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.registerFactorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.factorTableAdapter = new ShopDB.ShopDBDataSetTableAdapters.FactorTableAdapter();
            this.customersTableAdapter = new ShopDB.ShopDBDataSetTableAdapters.CustomersTableAdapter();
            this.goodsTableAdapter = new ShopDB.ShopDBDataSetTableAdapters.GoodsTableAdapter();
            this.registerFactorTableAdapter = new ShopDB.ShopDBDataSetTableAdapters.RegisterFactorTableAdapter();
            this.logOfGoodsTableAdapter = new ShopDB.ShopDBDataSetTableAdapters.LogOfGoodsTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabFactors.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGoodTab)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCustomerTab)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFactor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabGoods.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGood)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.tabCustomers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCustomers_Customer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.tabReports.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLog)).BeginInit();
            this.tabFactorTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFactorTable)).BeginInit();
            this.tabRegisterFactor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRegisterFactor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKFactorCustomersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKFactorCustomersBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logOfGoodsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.factorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.registerFactorBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabFactors);
            this.tabControl1.Controls.Add(this.tabGoods);
            this.tabControl1.Controls.Add(this.tabCustomers);
            this.tabControl1.Controls.Add(this.tabReports);
            this.tabControl1.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tabControl1.Location = new System.Drawing.Point(21, 30);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tabControl1.RightToLeftLayout = true;
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(854, 516);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabFactors
            // 
            this.tabFactors.BackColor = System.Drawing.Color.White;
            this.tabFactors.Controls.Add(this.lblAmountAfter_Factor);
            this.tabFactors.Controls.Add(this.label19);
            this.tabFactors.Controls.Add(this.label18);
            this.tabFactors.Controls.Add(this.lblAmount_Factor);
            this.tabFactors.Controls.Add(this.lblGoodName_Factor);
            this.tabFactors.Controls.Add(this.lblGoodUnitPrice_Factor);
            this.tabFactors.Controls.Add(this.lblCustomerPhone_Factor);
            this.tabFactors.Controls.Add(this.lblCutomerName_Factor);
            this.tabFactors.Controls.Add(this.lblFactorDate_Factor);
            this.tabFactors.Controls.Add(this.lblFactorID_Factor);
            this.tabFactors.Controls.Add(this.label11);
            this.tabFactors.Controls.Add(this.txtCountGood_Factor);
            this.tabFactors.Controls.Add(this.txtDiscount_Factor);
            this.tabFactors.Controls.Add(this.picGoodTab);
            this.tabFactors.Controls.Add(this.picCustomerTab);
            this.tabFactors.Controls.Add(this.label10);
            this.tabFactors.Controls.Add(this.label9);
            this.tabFactors.Controls.Add(this.btnClear_Factor);
            this.tabFactors.Controls.Add(this.btnInsertFactorRegister_Factor);
            this.tabFactors.Controls.Add(this.btnInsertCart_Factor);
            this.tabFactors.Controls.Add(this.label27);
            this.tabFactors.Controls.Add(this.label8);
            this.tabFactors.Controls.Add(this.label7);
            this.tabFactors.Controls.Add(this.comboGoodID_Factor);
            this.tabFactors.Controls.Add(this.label6);
            this.tabFactors.Controls.Add(this.label5);
            this.tabFactors.Controls.Add(this.label4);
            this.tabFactors.Controls.Add(this.label3);
            this.tabFactors.Controls.Add(this.comboCustomerID_Factor);
            this.tabFactors.Controls.Add(this.label2);
            this.tabFactors.Controls.Add(this.label1);
            this.tabFactors.Controls.Add(this.dataGridViewFactor);
            this.tabFactors.Controls.Add(this.pictureBox1);
            this.tabFactors.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tabFactors.Location = new System.Drawing.Point(4, 39);
            this.tabFactors.Name = "tabFactors";
            this.tabFactors.Padding = new System.Windows.Forms.Padding(3);
            this.tabFactors.Size = new System.Drawing.Size(846, 473);
            this.tabFactors.TabIndex = 0;
            this.tabFactors.Text = " برگه خرید";
            // 
            // lblAmountAfter_Factor
            // 
            this.lblAmountAfter_Factor.AutoSize = true;
            this.lblAmountAfter_Factor.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblAmountAfter_Factor.ForeColor = System.Drawing.Color.OrangeRed;
            this.lblAmountAfter_Factor.Location = new System.Drawing.Point(105, 371);
            this.lblAmountAfter_Factor.Name = "lblAmountAfter_Factor";
            this.lblAmountAfter_Factor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblAmountAfter_Factor.Size = new System.Drawing.Size(0, 29);
            this.lblAmountAfter_Factor.TabIndex = 48;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label19.Location = new System.Drawing.Point(6, 371);
            this.label19.Name = "label19";
            this.label19.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label19.Size = new System.Drawing.Size(44, 29);
            this.label19.TabIndex = 47;
            this.label19.Text = "ریال";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label18.Location = new System.Drawing.Point(6, 333);
            this.label18.Name = "label18";
            this.label18.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label18.Size = new System.Drawing.Size(44, 29);
            this.label18.TabIndex = 46;
            this.label18.Text = "ریال";
            // 
            // lblAmount_Factor
            // 
            this.lblAmount_Factor.AutoSize = true;
            this.lblAmount_Factor.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblAmount_Factor.ForeColor = System.Drawing.Color.OrangeRed;
            this.lblAmount_Factor.Location = new System.Drawing.Point(105, 333);
            this.lblAmount_Factor.Name = "lblAmount_Factor";
            this.lblAmount_Factor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblAmount_Factor.Size = new System.Drawing.Size(0, 29);
            this.lblAmount_Factor.TabIndex = 45;
            // 
            // lblGoodName_Factor
            // 
            this.lblGoodName_Factor.AutoSize = true;
            this.lblGoodName_Factor.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblGoodName_Factor.ForeColor = System.Drawing.Color.OrangeRed;
            this.lblGoodName_Factor.Location = new System.Drawing.Point(546, 257);
            this.lblGoodName_Factor.Name = "lblGoodName_Factor";
            this.lblGoodName_Factor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblGoodName_Factor.Size = new System.Drawing.Size(0, 29);
            this.lblGoodName_Factor.TabIndex = 44;
            // 
            // lblGoodUnitPrice_Factor
            // 
            this.lblGoodUnitPrice_Factor.AutoSize = true;
            this.lblGoodUnitPrice_Factor.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblGoodUnitPrice_Factor.ForeColor = System.Drawing.Color.OrangeRed;
            this.lblGoodUnitPrice_Factor.Location = new System.Drawing.Point(546, 342);
            this.lblGoodUnitPrice_Factor.Name = "lblGoodUnitPrice_Factor";
            this.lblGoodUnitPrice_Factor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblGoodUnitPrice_Factor.Size = new System.Drawing.Size(0, 29);
            this.lblGoodUnitPrice_Factor.TabIndex = 44;
            // 
            // lblCustomerPhone_Factor
            // 
            this.lblCustomerPhone_Factor.AutoSize = true;
            this.lblCustomerPhone_Factor.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblCustomerPhone_Factor.ForeColor = System.Drawing.Color.OrangeRed;
            this.lblCustomerPhone_Factor.Location = new System.Drawing.Point(546, 171);
            this.lblCustomerPhone_Factor.Name = "lblCustomerPhone_Factor";
            this.lblCustomerPhone_Factor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblCustomerPhone_Factor.Size = new System.Drawing.Size(0, 29);
            this.lblCustomerPhone_Factor.TabIndex = 43;
            // 
            // lblCutomerName_Factor
            // 
            this.lblCutomerName_Factor.AutoSize = true;
            this.lblCutomerName_Factor.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblCutomerName_Factor.ForeColor = System.Drawing.Color.OrangeRed;
            this.lblCutomerName_Factor.Location = new System.Drawing.Point(546, 133);
            this.lblCutomerName_Factor.Name = "lblCutomerName_Factor";
            this.lblCutomerName_Factor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblCutomerName_Factor.Size = new System.Drawing.Size(0, 29);
            this.lblCutomerName_Factor.TabIndex = 42;
            // 
            // lblFactorDate_Factor
            // 
            this.lblFactorDate_Factor.AutoSize = true;
            this.lblFactorDate_Factor.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblFactorDate_Factor.ForeColor = System.Drawing.Color.OrangeRed;
            this.lblFactorDate_Factor.Location = new System.Drawing.Point(546, 50);
            this.lblFactorDate_Factor.Name = "lblFactorDate_Factor";
            this.lblFactorDate_Factor.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblFactorDate_Factor.Size = new System.Drawing.Size(0, 21);
            this.lblFactorDate_Factor.TabIndex = 41;
            // 
            // lblFactorID_Factor
            // 
            this.lblFactorID_Factor.AutoSize = true;
            this.lblFactorID_Factor.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblFactorID_Factor.ForeColor = System.Drawing.Color.OrangeRed;
            this.lblFactorID_Factor.Location = new System.Drawing.Point(546, 13);
            this.lblFactorID_Factor.Name = "lblFactorID_Factor";
            this.lblFactorID_Factor.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblFactorID_Factor.Size = new System.Drawing.Size(0, 29);
            this.lblFactorID_Factor.TabIndex = 40;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label11.Location = new System.Drawing.Point(290, 333);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label11.Size = new System.Drawing.Size(143, 29);
            this.label11.TabIndex = 39;
            this.label11.Text = "مبلغ بدون تخفیف :";
            // 
            // txtCountGood_Factor
            // 
            this.txtCountGood_Factor.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCountGood_Factor.Location = new System.Drawing.Point(526, 296);
            this.txtCountGood_Factor.Name = "txtCountGood_Factor";
            this.txtCountGood_Factor.Size = new System.Drawing.Size(189, 36);
            this.txtCountGood_Factor.TabIndex = 38;
            this.txtCountGood_Factor.TextChanged += new System.EventHandler(this.txtCountGood_Factor_TextChanged);
            // 
            // txtDiscount_Factor
            // 
            this.txtDiscount_Factor.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtDiscount_Factor.Location = new System.Drawing.Point(526, 380);
            this.txtDiscount_Factor.Name = "txtDiscount_Factor";
            this.txtDiscount_Factor.Size = new System.Drawing.Size(189, 36);
            this.txtDiscount_Factor.TabIndex = 37;
            this.txtDiscount_Factor.TextChanged += new System.EventHandler(this.txtDiscount_Factor_TextChanged);
            // 
            // picGoodTab
            // 
            this.picGoodTab.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picGoodTab.Image = global::ShopDB.Properties.Resources._3;
            this.picGoodTab.Location = new System.Drawing.Point(485, 214);
            this.picGoodTab.Name = "picGoodTab";
            this.picGoodTab.Size = new System.Drawing.Size(30, 20);
            this.picGoodTab.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picGoodTab.TabIndex = 36;
            this.picGoodTab.TabStop = false;
            this.picGoodTab.Click += new System.EventHandler(this.picGoodTab_Click);
            // 
            // picCustomerTab
            // 
            this.picCustomerTab.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picCustomerTab.Image = global::ShopDB.Properties.Resources._3;
            this.picCustomerTab.Location = new System.Drawing.Point(485, 95);
            this.picCustomerTab.Name = "picCustomerTab";
            this.picCustomerTab.Size = new System.Drawing.Size(30, 20);
            this.picCustomerTab.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCustomerTab.TabIndex = 35;
            this.picCustomerTab.TabStop = false;
            this.picCustomerTab.Click += new System.EventHandler(this.picCustomerTab_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label10.Location = new System.Drawing.Point(269, 371);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label10.Size = new System.Drawing.Size(164, 29);
            this.label10.TabIndex = 34;
            this.label10.Text = "مبلغ قابل پرداخت :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label9.Location = new System.Drawing.Point(721, 386);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label9.Size = new System.Drawing.Size(114, 29);
            this.label9.TabIndex = 33;
            this.label9.Text = "درصد تخفیف :";
            // 
            // btnClear_Factor
            // 
            this.btnClear_Factor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnClear_Factor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear_Factor.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnClear_Factor.ForeColor = System.Drawing.Color.White;
            this.btnClear_Factor.Location = new System.Drawing.Point(6, 423);
            this.btnClear_Factor.Name = "btnClear_Factor";
            this.btnClear_Factor.Size = new System.Drawing.Size(175, 36);
            this.btnClear_Factor.TabIndex = 32;
            this.btnClear_Factor.Text = "پاک کردن";
            this.btnClear_Factor.UseVisualStyleBackColor = false;
            this.btnClear_Factor.Click += new System.EventHandler(this.btnClear_Factor_Click);
            // 
            // btnInsertFactorRegister_Factor
            // 
            this.btnInsertFactorRegister_Factor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnInsertFactorRegister_Factor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsertFactorRegister_Factor.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnInsertFactorRegister_Factor.ForeColor = System.Drawing.Color.White;
            this.btnInsertFactorRegister_Factor.Location = new System.Drawing.Point(253, 423);
            this.btnInsertFactorRegister_Factor.Name = "btnInsertFactorRegister_Factor";
            this.btnInsertFactorRegister_Factor.Size = new System.Drawing.Size(175, 36);
            this.btnInsertFactorRegister_Factor.TabIndex = 31;
            this.btnInsertFactorRegister_Factor.Text = "ثبت برگه خرید";
            this.btnInsertFactorRegister_Factor.UseVisualStyleBackColor = false;
            this.btnInsertFactorRegister_Factor.Click += new System.EventHandler(this.btnInsertFactorRegister_Factor_Click);
            // 
            // btnInsertCart_Factor
            // 
            this.btnInsertCart_Factor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnInsertCart_Factor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsertCart_Factor.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnInsertCart_Factor.ForeColor = System.Drawing.Color.White;
            this.btnInsertCart_Factor.Location = new System.Drawing.Point(503, 423);
            this.btnInsertCart_Factor.Name = "btnInsertCart_Factor";
            this.btnInsertCart_Factor.Size = new System.Drawing.Size(175, 36);
            this.btnInsertCart_Factor.TabIndex = 30;
            this.btnInsertCart_Factor.Text = "درج در سبد خرید";
            this.btnInsertCart_Factor.UseVisualStyleBackColor = false;
            this.btnInsertCart_Factor.Click += new System.EventHandler(this.btnInsertCart_Factor_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label27.Location = new System.Drawing.Point(767, 257);
            this.label27.Name = "label27";
            this.label27.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label27.Size = new System.Drawing.Size(68, 29);
            this.label27.TabIndex = 29;
            this.label27.Text = "نام کالا :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label8.Location = new System.Drawing.Point(748, 342);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label8.Size = new System.Drawing.Size(87, 29);
            this.label8.TabIndex = 29;
            this.label8.Text = "قیمت کالا :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label7.Location = new System.Drawing.Point(774, 300);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label7.Size = new System.Drawing.Size(61, 29);
            this.label7.TabIndex = 28;
            this.label7.Text = "تعداد :";
            // 
            // comboGoodID_Factor
            // 
            this.comboGoodID_Factor.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comboGoodID_Factor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comboGoodID_Factor.Font = new System.Drawing.Font("B Yekan", 14.25F);
            this.comboGoodID_Factor.FormattingEnabled = true;
            this.comboGoodID_Factor.Location = new System.Drawing.Point(526, 207);
            this.comboGoodID_Factor.Name = "comboGoodID_Factor";
            this.comboGoodID_Factor.Size = new System.Drawing.Size(189, 37);
            this.comboGoodID_Factor.Sorted = true;
            this.comboGoodID_Factor.TabIndex = 27;
            this.comboGoodID_Factor.SelectedIndexChanged += new System.EventHandler(this.comboGoodID_Factor_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label6.Location = new System.Drawing.Point(768, 210);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label6.Size = new System.Drawing.Size(67, 29);
            this.label6.TabIndex = 26;
            this.label6.Text = "کد کالا :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label5.Location = new System.Drawing.Point(780, 171);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label5.Size = new System.Drawing.Size(55, 29);
            this.label5.TabIndex = 25;
            this.label5.Text = "تلفن :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.Location = new System.Drawing.Point(740, 133);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label4.Size = new System.Drawing.Size(95, 29);
            this.label4.TabIndex = 24;
            this.label4.Text = "نام مشتری :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.Location = new System.Drawing.Point(741, 91);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(94, 29);
            this.label3.TabIndex = 23;
            this.label3.Text = "کد مشتری :";
            // 
            // comboCustomerID_Factor
            // 
            this.comboCustomerID_Factor.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comboCustomerID_Factor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comboCustomerID_Factor.Font = new System.Drawing.Font("B Yekan", 14.25F);
            this.comboCustomerID_Factor.FormattingEnabled = true;
            this.comboCustomerID_Factor.Location = new System.Drawing.Point(526, 88);
            this.comboCustomerID_Factor.Name = "comboCustomerID_Factor";
            this.comboCustomerID_Factor.Size = new System.Drawing.Size(189, 37);
            this.comboCustomerID_Factor.Sorted = true;
            this.comboCustomerID_Factor.TabIndex = 22;
            this.comboCustomerID_Factor.SelectedIndexChanged += new System.EventHandler(this.comboCustomerID_Factor_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Location = new System.Drawing.Point(698, 13);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(137, 29);
            this.label2.TabIndex = 21;
            this.label2.Text = "شماره برگه خرید :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(779, 50);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(56, 29);
            this.label1.TabIndex = 20;
            this.label1.Text = "تاریخ :";
            // 
            // dataGridViewFactor
            // 
            this.dataGridViewFactor.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewFactor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFactor.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.goodCode,
            this.goodName,
            this.goodCount,
            this.unitPrice,
            this.AllCost,
            this.remove});
            this.dataGridViewFactor.Location = new System.Drawing.Point(15, 51);
            this.dataGridViewFactor.Name = "dataGridViewFactor";
            this.dataGridViewFactor.Size = new System.Drawing.Size(443, 268);
            this.dataGridViewFactor.TabIndex = 18;
            this.dataGridViewFactor.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewFactor_CellContentClick);
            // 
            // goodCode
            // 
            this.goodCode.FillWeight = 80F;
            this.goodCode.HeaderText = "کد کالا";
            this.goodCode.Name = "goodCode";
            this.goodCode.ReadOnly = true;
            this.goodCode.Width = 80;
            // 
            // goodName
            // 
            this.goodName.FillWeight = 85F;
            this.goodName.HeaderText = "نام کالا";
            this.goodName.Name = "goodName";
            this.goodName.ReadOnly = true;
            this.goodName.Width = 85;
            // 
            // goodCount
            // 
            this.goodCount.HeaderText = "تعداد";
            this.goodCount.Name = "goodCount";
            this.goodCount.Width = 50;
            // 
            // unitPrice
            // 
            this.unitPrice.FillWeight = 75F;
            this.unitPrice.HeaderText = "قیمت واحد(ریال)";
            this.unitPrice.Name = "unitPrice";
            this.unitPrice.ReadOnly = true;
            this.unitPrice.Width = 75;
            // 
            // AllCost
            // 
            this.AllCost.FillWeight = 80F;
            this.AllCost.HeaderText = "قیمت کل(ریال)";
            this.AllCost.Name = "AllCost";
            this.AllCost.ReadOnly = true;
            this.AllCost.Width = 80;
            // 
            // remove
            // 
            this.remove.HeaderText = "";
            this.remove.Image = global::ShopDB.Properties.Resources.remove;
            this.remove.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.remove.Name = "remove";
            this.remove.Width = 30;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ShopDB.Properties.Resources.factor2;
            this.pictureBox1.Location = new System.Drawing.Point(6, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(461, 322);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // tabGoods
            // 
            this.tabGoods.Controls.Add(this.dataGridViewGood);
            this.tabGoods.Controls.Add(this.btnClear_Good);
            this.tabGoods.Controls.Add(this.btnInsertToGoodTab_Good);
            this.tabGoods.Controls.Add(this.btnDeleteGood_Good);
            this.tabGoods.Controls.Add(this.btnUpdateGood_Good);
            this.tabGoods.Controls.Add(this.btnInsertGood_Good);
            this.tabGoods.Controls.Add(this.txtGoodStocks_Good);
            this.tabGoods.Controls.Add(this.label16);
            this.tabGoods.Controls.Add(this.txtGoodUnitPrice_Good);
            this.tabGoods.Controls.Add(this.label17);
            this.tabGoods.Controls.Add(this.txtGoodName_Good);
            this.tabGoods.Controls.Add(this.label14);
            this.tabGoods.Controls.Add(this.txtGoodID_Good);
            this.tabGoods.Controls.Add(this.label15);
            this.tabGoods.Controls.Add(this.pictureBox6);
            this.tabGoods.Controls.Add(this.txtGoodNameSearch_Good);
            this.tabGoods.Controls.Add(this.label13);
            this.tabGoods.Controls.Add(this.txtGoodIDSearch_Good);
            this.tabGoods.Controls.Add(this.label12);
            this.tabGoods.Controls.Add(this.pictureBox4);
            this.tabGoods.Controls.Add(this.pictureBox5);
            this.tabGoods.Location = new System.Drawing.Point(4, 39);
            this.tabGoods.Name = "tabGoods";
            this.tabGoods.Padding = new System.Windows.Forms.Padding(3);
            this.tabGoods.Size = new System.Drawing.Size(846, 473);
            this.tabGoods.TabIndex = 1;
            this.tabGoods.Text = "     کالا";
            this.tabGoods.UseVisualStyleBackColor = true;
            // 
            // dataGridViewGood
            // 
            this.dataGridViewGood.AutoGenerateColumns = false;
            this.dataGridViewGood.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewGood.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGood.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.goodsIDDataGridViewTextBoxColumn,
            this.goodsNameDataGridViewTextBoxColumn,
            this.goodsUnitPriceDataGridViewTextBoxColumn,
            this.goodsStockDataGridViewTextBoxColumn});
            this.dataGridViewGood.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridViewGood.DataSource = this.goodsBindingSource;
            this.dataGridViewGood.Location = new System.Drawing.Point(18, 69);
            this.dataGridViewGood.Name = "dataGridViewGood";
            this.dataGridViewGood.Size = new System.Drawing.Size(443, 378);
            this.dataGridViewGood.TabIndex = 62;
            this.dataGridViewGood.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewGood_CellContentClick);
            // 
            // btnClear_Good
            // 
            this.btnClear_Good.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnClear_Good.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear_Good.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnClear_Good.ForeColor = System.Drawing.Color.White;
            this.btnClear_Good.Location = new System.Drawing.Point(721, 411);
            this.btnClear_Good.Name = "btnClear_Good";
            this.btnClear_Good.Size = new System.Drawing.Size(96, 36);
            this.btnClear_Good.TabIndex = 59;
            this.btnClear_Good.Text = "پاک کردن";
            this.btnClear_Good.UseVisualStyleBackColor = false;
            this.btnClear_Good.Click += new System.EventHandler(this.btnClear_Good_Click);
            // 
            // btnInsertToGoodTab_Good
            // 
            this.btnInsertToGoodTab_Good.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnInsertToGoodTab_Good.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsertToGoodTab_Good.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnInsertToGoodTab_Good.ForeColor = System.Drawing.Color.White;
            this.btnInsertToGoodTab_Good.Location = new System.Drawing.Point(512, 411);
            this.btnInsertToGoodTab_Good.Name = "btnInsertToGoodTab_Good";
            this.btnInsertToGoodTab_Good.Size = new System.Drawing.Size(203, 36);
            this.btnInsertToGoodTab_Good.TabIndex = 58;
            this.btnInsertToGoodTab_Good.Text = "درج در برگه خرید";
            this.btnInsertToGoodTab_Good.UseVisualStyleBackColor = false;
            this.btnInsertToGoodTab_Good.Click += new System.EventHandler(this.btnInsertToGoodTab_Good_Click);
            // 
            // btnDeleteGood_Good
            // 
            this.btnDeleteGood_Good.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDeleteGood_Good.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeleteGood_Good.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnDeleteGood_Good.ForeColor = System.Drawing.Color.White;
            this.btnDeleteGood_Good.Location = new System.Drawing.Point(512, 367);
            this.btnDeleteGood_Good.Name = "btnDeleteGood_Good";
            this.btnDeleteGood_Good.Size = new System.Drawing.Size(96, 36);
            this.btnDeleteGood_Good.TabIndex = 57;
            this.btnDeleteGood_Good.Text = "حذف";
            this.btnDeleteGood_Good.UseVisualStyleBackColor = false;
            this.btnDeleteGood_Good.Click += new System.EventHandler(this.btnDeleteGood_Good_Click);
            // 
            // btnUpdateGood_Good
            // 
            this.btnUpdateGood_Good.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnUpdateGood_Good.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdateGood_Good.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnUpdateGood_Good.ForeColor = System.Drawing.Color.White;
            this.btnUpdateGood_Good.Location = new System.Drawing.Point(619, 367);
            this.btnUpdateGood_Good.Name = "btnUpdateGood_Good";
            this.btnUpdateGood_Good.Size = new System.Drawing.Size(96, 36);
            this.btnUpdateGood_Good.TabIndex = 56;
            this.btnUpdateGood_Good.Text = "ویرایش";
            this.btnUpdateGood_Good.UseVisualStyleBackColor = false;
            this.btnUpdateGood_Good.Click += new System.EventHandler(this.btnUpdateGood_Good_Click);
            // 
            // btnInsertGood_Good
            // 
            this.btnInsertGood_Good.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnInsertGood_Good.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsertGood_Good.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnInsertGood_Good.ForeColor = System.Drawing.Color.White;
            this.btnInsertGood_Good.Location = new System.Drawing.Point(721, 368);
            this.btnInsertGood_Good.Name = "btnInsertGood_Good";
            this.btnInsertGood_Good.Size = new System.Drawing.Size(96, 36);
            this.btnInsertGood_Good.TabIndex = 55;
            this.btnInsertGood_Good.Text = "ثبت";
            this.btnInsertGood_Good.UseVisualStyleBackColor = false;
            this.btnInsertGood_Good.Click += new System.EventHandler(this.btnInsertGood_Good_Click);
            // 
            // txtGoodStocks_Good
            // 
            this.txtGoodStocks_Good.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtGoodStocks_Good.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtGoodStocks_Good.Location = new System.Drawing.Point(512, 304);
            this.txtGoodStocks_Good.Name = "txtGoodStocks_Good";
            this.txtGoodStocks_Good.Size = new System.Drawing.Size(208, 36);
            this.txtGoodStocks_Good.TabIndex = 53;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label16.Location = new System.Drawing.Point(746, 306);
            this.label16.Name = "label16";
            this.label16.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label16.Size = new System.Drawing.Size(77, 29);
            this.label16.TabIndex = 52;
            this.label16.Text = "موجودی :";
            // 
            // txtGoodUnitPrice_Good
            // 
            this.txtGoodUnitPrice_Good.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtGoodUnitPrice_Good.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtGoodUnitPrice_Good.Location = new System.Drawing.Point(512, 260);
            this.txtGoodUnitPrice_Good.Name = "txtGoodUnitPrice_Good";
            this.txtGoodUnitPrice_Good.Size = new System.Drawing.Size(208, 36);
            this.txtGoodUnitPrice_Good.TabIndex = 51;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label17.Location = new System.Drawing.Point(724, 260);
            this.label17.Name = "label17";
            this.label17.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label17.Size = new System.Drawing.Size(99, 29);
            this.label17.TabIndex = 50;
            this.label17.Text = "قیمت واحد :";
            // 
            // txtGoodName_Good
            // 
            this.txtGoodName_Good.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtGoodName_Good.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtGoodName_Good.Location = new System.Drawing.Point(512, 214);
            this.txtGoodName_Good.Name = "txtGoodName_Good";
            this.txtGoodName_Good.Size = new System.Drawing.Size(208, 36);
            this.txtGoodName_Good.TabIndex = 49;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label14.Location = new System.Drawing.Point(755, 216);
            this.label14.Name = "label14";
            this.label14.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label14.Size = new System.Drawing.Size(68, 29);
            this.label14.TabIndex = 48;
            this.label14.Text = "نام کالا :";
            // 
            // txtGoodID_Good
            // 
            this.txtGoodID_Good.BackColor = System.Drawing.Color.LightGray;
            this.txtGoodID_Good.Enabled = false;
            this.txtGoodID_Good.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtGoodID_Good.Location = new System.Drawing.Point(512, 169);
            this.txtGoodID_Good.Name = "txtGoodID_Good";
            this.txtGoodID_Good.ReadOnly = true;
            this.txtGoodID_Good.Size = new System.Drawing.Size(208, 36);
            this.txtGoodID_Good.TabIndex = 47;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label15.Location = new System.Drawing.Point(756, 171);
            this.label15.Name = "label15";
            this.label15.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label15.Size = new System.Drawing.Size(67, 29);
            this.label15.TabIndex = 46;
            this.label15.Text = "کد کالا :";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ShopDB.Properties.Resources._42;
            this.pictureBox6.Location = new System.Drawing.Point(497, 161);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(332, 298);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 45;
            this.pictureBox6.TabStop = false;
            // 
            // txtGoodNameSearch_Good
            // 
            this.txtGoodNameSearch_Good.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtGoodNameSearch_Good.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtGoodNameSearch_Good.Location = new System.Drawing.Point(512, 109);
            this.txtGoodNameSearch_Good.Name = "txtGoodNameSearch_Good";
            this.txtGoodNameSearch_Good.Size = new System.Drawing.Size(208, 36);
            this.txtGoodNameSearch_Good.TabIndex = 44;
            this.txtGoodNameSearch_Good.TextChanged += new System.EventHandler(this.txtGoodNameSearch_Good_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label13.Location = new System.Drawing.Point(755, 111);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label13.Size = new System.Drawing.Size(68, 29);
            this.label13.TabIndex = 43;
            this.label13.Text = "نام کالا :";
            // 
            // txtGoodIDSearch_Good
            // 
            this.txtGoodIDSearch_Good.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtGoodIDSearch_Good.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtGoodIDSearch_Good.Location = new System.Drawing.Point(512, 61);
            this.txtGoodIDSearch_Good.Name = "txtGoodIDSearch_Good";
            this.txtGoodIDSearch_Good.Size = new System.Drawing.Size(208, 36);
            this.txtGoodIDSearch_Good.TabIndex = 41;
            this.txtGoodIDSearch_Good.TextChanged += new System.EventHandler(this.txtGoodIDSearch_Good_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label12.Location = new System.Drawing.Point(756, 63);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label12.Size = new System.Drawing.Size(67, 29);
            this.label12.TabIndex = 39;
            this.label12.Text = "کد کالا :";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ShopDB.Properties.Resources.good;
            this.pictureBox4.Location = new System.Drawing.Point(8, 15);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(461, 444);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 20;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::ShopDB.Properties.Resources._31;
            this.pictureBox5.Location = new System.Drawing.Point(497, 15);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(332, 140);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 42;
            this.pictureBox5.TabStop = false;
            // 
            // tabCustomers
            // 
            this.tabCustomers.Controls.Add(this.txtNameSearch_Customer);
            this.tabCustomers.Controls.Add(this.txtIDSearch_Customer);
            this.tabCustomers.Controls.Add(this.btnInsertToFactorTab_Customer);
            this.tabCustomers.Controls.Add(this.txtCustomerBirthday_Customer);
            this.tabCustomers.Controls.Add(this.label26);
            this.tabCustomers.Controls.Add(this.dataGridViewCustomers_Customer);
            this.tabCustomers.Controls.Add(this.btnDeleteCustomer_Customer);
            this.tabCustomers.Controls.Add(this.btnClear_Customer);
            this.tabCustomers.Controls.Add(this.btnUpdateCustomer_Customer);
            this.tabCustomers.Controls.Add(this.btnInsertCustomer_Customer);
            this.tabCustomers.Controls.Add(this.txtCustomerTel_Customer);
            this.tabCustomers.Controls.Add(this.label20);
            this.tabCustomers.Controls.Add(this.txtCustomerLName_Customer);
            this.tabCustomers.Controls.Add(this.label21);
            this.tabCustomers.Controls.Add(this.txtCustomerFName_Customer);
            this.tabCustomers.Controls.Add(this.label22);
            this.tabCustomers.Controls.Add(this.txtCustomerID_Customer);
            this.tabCustomers.Controls.Add(this.label23);
            this.tabCustomers.Controls.Add(this.label24);
            this.tabCustomers.Controls.Add(this.label25);
            this.tabCustomers.Controls.Add(this.pictureBox8);
            this.tabCustomers.Controls.Add(this.pictureBox9);
            this.tabCustomers.Controls.Add(this.pictureBox7);
            this.tabCustomers.Location = new System.Drawing.Point(4, 39);
            this.tabCustomers.Name = "tabCustomers";
            this.tabCustomers.Padding = new System.Windows.Forms.Padding(3);
            this.tabCustomers.Size = new System.Drawing.Size(846, 473);
            this.tabCustomers.TabIndex = 2;
            this.tabCustomers.Text = "  مشتری";
            this.tabCustomers.UseVisualStyleBackColor = true;
            // 
            // txtNameSearch_Customer
            // 
            this.txtNameSearch_Customer.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtNameSearch_Customer.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtNameSearch_Customer.Location = new System.Drawing.Point(512, 95);
            this.txtNameSearch_Customer.Name = "txtNameSearch_Customer";
            this.txtNameSearch_Customer.Size = new System.Drawing.Size(203, 36);
            this.txtNameSearch_Customer.TabIndex = 91;
            this.txtNameSearch_Customer.TextChanged += new System.EventHandler(this.txtNameSearch_Customer_TextChanged);
            // 
            // txtIDSearch_Customer
            // 
            this.txtIDSearch_Customer.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtIDSearch_Customer.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtIDSearch_Customer.Location = new System.Drawing.Point(512, 47);
            this.txtIDSearch_Customer.Name = "txtIDSearch_Customer";
            this.txtIDSearch_Customer.Size = new System.Drawing.Size(203, 36);
            this.txtIDSearch_Customer.TabIndex = 90;
            this.txtIDSearch_Customer.TextChanged += new System.EventHandler(this.txtIDSearch_Customer_TextChanged);
            // 
            // btnInsertToFactorTab_Customer
            // 
            this.btnInsertToFactorTab_Customer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnInsertToFactorTab_Customer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsertToFactorTab_Customer.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnInsertToFactorTab_Customer.ForeColor = System.Drawing.Color.White;
            this.btnInsertToFactorTab_Customer.Location = new System.Drawing.Point(517, 417);
            this.btnInsertToFactorTab_Customer.Name = "btnInsertToFactorTab_Customer";
            this.btnInsertToFactorTab_Customer.Size = new System.Drawing.Size(203, 36);
            this.btnInsertToFactorTab_Customer.TabIndex = 59;
            this.btnInsertToFactorTab_Customer.Text = "درج در برگه خرید";
            this.btnInsertToFactorTab_Customer.UseVisualStyleBackColor = false;
            this.btnInsertToFactorTab_Customer.Click += new System.EventHandler(this.btnInsertToFactorTab_Customer_Click);
            // 
            // txtCustomerBirthday_Customer
            // 
            this.txtCustomerBirthday_Customer.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCustomerBirthday_Customer.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerBirthday_Customer.Location = new System.Drawing.Point(517, 337);
            this.txtCustomerBirthday_Customer.Name = "txtCustomerBirthday_Customer";
            this.txtCustomerBirthday_Customer.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtCustomerBirthday_Customer.Size = new System.Drawing.Size(198, 29);
            this.txtCustomerBirthday_Customer.TabIndex = 89;
            this.txtCustomerBirthday_Customer.TextChanged += new System.EventHandler(this.txtCustomerBirthday_Customer_TextChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label26.Location = new System.Drawing.Point(738, 340);
            this.label26.Name = "label26";
            this.label26.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label26.Size = new System.Drawing.Size(90, 29);
            this.label26.TabIndex = 88;
            this.label26.Text = "تاریخ تولد :";
            // 
            // dataGridViewCustomers_Customer
            // 
            this.dataGridViewCustomers_Customer.AutoGenerateColumns = false;
            this.dataGridViewCustomers_Customer.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewCustomers_Customer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCustomers_Customer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.customerIDDataGridViewTextBoxColumn,
            this.customerNameDataGridViewTextBoxColumn,
            this.customerFamilyDataGridViewTextBoxColumn,
            this.customerPhoneDataGridViewTextBoxColumn,
            this.customerBirthdayDataGridViewTextBoxColumn,
            this.customerAgeDataGridViewTextBoxColumn});
            this.dataGridViewCustomers_Customer.DataSource = this.customersBindingSource;
            this.dataGridViewCustomers_Customer.Location = new System.Drawing.Point(23, 65);
            this.dataGridViewCustomers_Customer.Name = "dataGridViewCustomers_Customer";
            this.dataGridViewCustomers_Customer.Size = new System.Drawing.Size(441, 378);
            this.dataGridViewCustomers_Customer.TabIndex = 87;
            this.dataGridViewCustomers_Customer.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewCustomers_Customer_CellContentClick);
            // 
            // btnDeleteCustomer_Customer
            // 
            this.btnDeleteCustomer_Customer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDeleteCustomer_Customer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeleteCustomer_Customer.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnDeleteCustomer_Customer.ForeColor = System.Drawing.Color.White;
            this.btnDeleteCustomer_Customer.Location = new System.Drawing.Point(727, 418);
            this.btnDeleteCustomer_Customer.Name = "btnDeleteCustomer_Customer";
            this.btnDeleteCustomer_Customer.Size = new System.Drawing.Size(96, 36);
            this.btnDeleteCustomer_Customer.TabIndex = 82;
            this.btnDeleteCustomer_Customer.Text = "پاک کردن";
            this.btnDeleteCustomer_Customer.UseVisualStyleBackColor = false;
            this.btnDeleteCustomer_Customer.Click += new System.EventHandler(this.btnDeleteCustomer_Customer_Click);
            // 
            // btnClear_Customer
            // 
            this.btnClear_Customer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnClear_Customer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear_Customer.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnClear_Customer.ForeColor = System.Drawing.Color.White;
            this.btnClear_Customer.Location = new System.Drawing.Point(517, 375);
            this.btnClear_Customer.Name = "btnClear_Customer";
            this.btnClear_Customer.Size = new System.Drawing.Size(96, 36);
            this.btnClear_Customer.TabIndex = 80;
            this.btnClear_Customer.Text = "حذف";
            this.btnClear_Customer.UseVisualStyleBackColor = false;
            this.btnClear_Customer.Click += new System.EventHandler(this.btnClear_Customer_Click);
            // 
            // btnUpdateCustomer_Customer
            // 
            this.btnUpdateCustomer_Customer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnUpdateCustomer_Customer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdateCustomer_Customer.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnUpdateCustomer_Customer.ForeColor = System.Drawing.Color.White;
            this.btnUpdateCustomer_Customer.Location = new System.Drawing.Point(624, 375);
            this.btnUpdateCustomer_Customer.Name = "btnUpdateCustomer_Customer";
            this.btnUpdateCustomer_Customer.Size = new System.Drawing.Size(96, 36);
            this.btnUpdateCustomer_Customer.TabIndex = 79;
            this.btnUpdateCustomer_Customer.Text = "ویرایش";
            this.btnUpdateCustomer_Customer.UseVisualStyleBackColor = false;
            this.btnUpdateCustomer_Customer.Click += new System.EventHandler(this.btnUpdateCustomer_Customer_Click);
            // 
            // btnInsertCustomer_Customer
            // 
            this.btnInsertCustomer_Customer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnInsertCustomer_Customer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsertCustomer_Customer.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnInsertCustomer_Customer.ForeColor = System.Drawing.Color.White;
            this.btnInsertCustomer_Customer.Location = new System.Drawing.Point(727, 375);
            this.btnInsertCustomer_Customer.Name = "btnInsertCustomer_Customer";
            this.btnInsertCustomer_Customer.Size = new System.Drawing.Size(96, 36);
            this.btnInsertCustomer_Customer.TabIndex = 78;
            this.btnInsertCustomer_Customer.Text = "ثبت";
            this.btnInsertCustomer_Customer.UseVisualStyleBackColor = false;
            this.btnInsertCustomer_Customer.Click += new System.EventHandler(this.btnInsertCustomer_Customer_Click);
            // 
            // txtCustomerTel_Customer
            // 
            this.txtCustomerTel_Customer.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCustomerTel_Customer.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtCustomerTel_Customer.Location = new System.Drawing.Point(517, 289);
            this.txtCustomerTel_Customer.Name = "txtCustomerTel_Customer";
            this.txtCustomerTel_Customer.Size = new System.Drawing.Size(198, 36);
            this.txtCustomerTel_Customer.TabIndex = 77;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label20.Location = new System.Drawing.Point(773, 296);
            this.label20.Name = "label20";
            this.label20.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label20.Size = new System.Drawing.Size(55, 29);
            this.label20.TabIndex = 76;
            this.label20.Text = "تلفن :";
            // 
            // txtCustomerLName_Customer
            // 
            this.txtCustomerLName_Customer.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCustomerLName_Customer.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtCustomerLName_Customer.Location = new System.Drawing.Point(517, 245);
            this.txtCustomerLName_Customer.Name = "txtCustomerLName_Customer";
            this.txtCustomerLName_Customer.Size = new System.Drawing.Size(198, 36);
            this.txtCustomerLName_Customer.TabIndex = 75;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label21.Location = new System.Drawing.Point(786, 206);
            this.label21.Name = "label21";
            this.label21.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label21.Size = new System.Drawing.Size(42, 29);
            this.label21.TabIndex = 74;
            this.label21.Text = "نام :";
            // 
            // txtCustomerFName_Customer
            // 
            this.txtCustomerFName_Customer.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCustomerFName_Customer.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtCustomerFName_Customer.Location = new System.Drawing.Point(517, 199);
            this.txtCustomerFName_Customer.Name = "txtCustomerFName_Customer";
            this.txtCustomerFName_Customer.Size = new System.Drawing.Size(198, 36);
            this.txtCustomerFName_Customer.TabIndex = 73;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label22.Location = new System.Drawing.Point(721, 252);
            this.label22.Name = "label22";
            this.label22.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label22.Size = new System.Drawing.Size(107, 29);
            this.label22.TabIndex = 72;
            this.label22.Text = "نام خانوادگی :";
            // 
            // txtCustomerID_Customer
            // 
            this.txtCustomerID_Customer.BackColor = System.Drawing.Color.LightGray;
            this.txtCustomerID_Customer.Enabled = false;
            this.txtCustomerID_Customer.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtCustomerID_Customer.Location = new System.Drawing.Point(517, 154);
            this.txtCustomerID_Customer.Name = "txtCustomerID_Customer";
            this.txtCustomerID_Customer.ReadOnly = true;
            this.txtCustomerID_Customer.Size = new System.Drawing.Size(198, 36);
            this.txtCustomerID_Customer.TabIndex = 71;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label23.Location = new System.Drawing.Point(734, 161);
            this.label23.Name = "label23";
            this.label23.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label23.Size = new System.Drawing.Size(94, 29);
            this.label23.TabIndex = 70;
            this.label23.Text = "کد مشتری :";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label24.Location = new System.Drawing.Point(721, 102);
            this.label24.Name = "label24";
            this.label24.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label24.Size = new System.Drawing.Size(107, 29);
            this.label24.TabIndex = 67;
            this.label24.Text = "نام خانوادگی :";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label25.Location = new System.Drawing.Point(734, 52);
            this.label25.Name = "label25";
            this.label25.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label25.Size = new System.Drawing.Size(94, 29);
            this.label25.TabIndex = 64;
            this.label25.Text = "کد مشتری :";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ShopDB.Properties.Resources.Customer;
            this.pictureBox8.Location = new System.Drawing.Point(13, 10);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(461, 444);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 63;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ShopDB.Properties.Resources._31;
            this.pictureBox9.Location = new System.Drawing.Point(502, 7);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(332, 135);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 66;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ShopDB.Properties.Resources._42;
            this.pictureBox7.Location = new System.Drawing.Point(502, 149);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(332, 308);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 69;
            this.pictureBox7.TabStop = false;
            // 
            // tabReports
            // 
            this.tabReports.Controls.Add(this.tabControl2);
            this.tabReports.Controls.Add(this.pictureBox3);
            this.tabReports.Location = new System.Drawing.Point(4, 39);
            this.tabReports.Name = "tabReports";
            this.tabReports.Padding = new System.Windows.Forms.Padding(3);
            this.tabReports.Size = new System.Drawing.Size(846, 473);
            this.tabReports.TabIndex = 3;
            this.tabReports.Text = "   گزارش";
            this.tabReports.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabLog);
            this.tabControl2.Controls.Add(this.tabFactorTable);
            this.tabControl2.Controls.Add(this.tabRegisterFactor);
            this.tabControl2.Location = new System.Drawing.Point(18, 64);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.RightToLeftLayout = true;
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(809, 395);
            this.tabControl2.TabIndex = 0;
            this.tabControl2.SelectedIndexChanged += new System.EventHandler(this.tabControl2_SelectedIndexChanged);
            // 
            // tabLog
            // 
            this.tabLog.Controls.Add(this.splitContainer1);
            this.tabLog.Location = new System.Drawing.Point(4, 39);
            this.tabLog.Name = "tabLog";
            this.tabLog.Padding = new System.Windows.Forms.Padding(3);
            this.tabLog.Size = new System.Drawing.Size(801, 352);
            this.tabLog.TabIndex = 0;
            this.tabLog.Text = "تغییرات جدول کالا";
            this.tabLog.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btnClearLog);
            this.splitContainer1.Panel1.Controls.Add(this.btnSearchAllLog);
            this.splitContainer1.Panel1.Controls.Add(this.txtGoodIdLog);
            this.splitContainer1.Panel1.Controls.Add(this.txtGoodNameLog);
            this.splitContainer1.Panel1.Controls.Add(this.btnSearchDateLog);
            this.splitContainer1.Panel1.Controls.Add(this.comboActionTypeLog);
            this.splitContainer1.Panel1.Controls.Add(this.label32);
            this.splitContainer1.Panel1.Controls.Add(this.label31);
            this.splitContainer1.Panel1.Controls.Add(this.label30);
            this.splitContainer1.Panel1.Controls.Add(this.txtDateEndLog);
            this.splitContainer1.Panel1.Controls.Add(this.label28);
            this.splitContainer1.Panel1.Controls.Add(this.txtDateStartLog);
            this.splitContainer1.Panel1.Controls.Add(this.label29);
            this.splitContainer1.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dataGridViewLog);
            this.splitContainer1.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer1.Size = new System.Drawing.Size(795, 346);
            this.splitContainer1.SplitterDistance = 265;
            this.splitContainer1.TabIndex = 1;
            // 
            // btnClearLog
            // 
            this.btnClearLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnClearLog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClearLog.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnClearLog.ForeColor = System.Drawing.Color.White;
            this.btnClearLog.Location = new System.Drawing.Point(12, 300);
            this.btnClearLog.Name = "btnClearLog";
            this.btnClearLog.Size = new System.Drawing.Size(242, 36);
            this.btnClearLog.TabIndex = 66;
            this.btnClearLog.Text = "پاک کردن ";
            this.btnClearLog.UseVisualStyleBackColor = false;
            this.btnClearLog.Click += new System.EventHandler(this.btnClearLog_Click);
            // 
            // btnSearchAllLog
            // 
            this.btnSearchAllLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSearchAllLog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearchAllLog.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSearchAllLog.ForeColor = System.Drawing.Color.White;
            this.btnSearchAllLog.Location = new System.Drawing.Point(12, 254);
            this.btnSearchAllLog.Name = "btnSearchAllLog";
            this.btnSearchAllLog.Size = new System.Drawing.Size(115, 36);
            this.btnSearchAllLog.TabIndex = 65;
            this.btnSearchAllLog.Text = "جستجو ترکیبی";
            this.btnSearchAllLog.UseVisualStyleBackColor = false;
            this.btnSearchAllLog.Click += new System.EventHandler(this.btnSearchAllLog_Click);
            // 
            // txtGoodIdLog
            // 
            this.txtGoodIdLog.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtGoodIdLog.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtGoodIdLog.Location = new System.Drawing.Point(12, 10);
            this.txtGoodIdLog.Name = "txtGoodIdLog";
            this.txtGoodIdLog.Size = new System.Drawing.Size(152, 36);
            this.txtGoodIdLog.TabIndex = 64;
            this.txtGoodIdLog.TextChanged += new System.EventHandler(this.txtGoodIdLog_TextChanged);
            // 
            // txtGoodNameLog
            // 
            this.txtGoodNameLog.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtGoodNameLog.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtGoodNameLog.Location = new System.Drawing.Point(12, 57);
            this.txtGoodNameLog.Name = "txtGoodNameLog";
            this.txtGoodNameLog.Size = new System.Drawing.Size(152, 36);
            this.txtGoodNameLog.TabIndex = 63;
            this.txtGoodNameLog.TextChanged += new System.EventHandler(this.txtGoodNameLog_TextChanged);
            // 
            // btnSearchDateLog
            // 
            this.btnSearchDateLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSearchDateLog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearchDateLog.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSearchDateLog.ForeColor = System.Drawing.Color.White;
            this.btnSearchDateLog.Location = new System.Drawing.Point(139, 253);
            this.btnSearchDateLog.Name = "btnSearchDateLog";
            this.btnSearchDateLog.Size = new System.Drawing.Size(115, 36);
            this.btnSearchDateLog.TabIndex = 62;
            this.btnSearchDateLog.Text = "جستجو تاریخ";
            this.btnSearchDateLog.UseVisualStyleBackColor = false;
            this.btnSearchDateLog.Click += new System.EventHandler(this.btnSearchDateLog_Click);
            // 
            // comboActionTypeLog
            // 
            this.comboActionTypeLog.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comboActionTypeLog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comboActionTypeLog.Font = new System.Drawing.Font("B Yekan", 14.25F);
            this.comboActionTypeLog.FormattingEnabled = true;
            this.comboActionTypeLog.Items.AddRange(new object[] {
            "Delete",
            "Insert",
            "Update"});
            this.comboActionTypeLog.Location = new System.Drawing.Point(12, 103);
            this.comboActionTypeLog.Name = "comboActionTypeLog";
            this.comboActionTypeLog.Size = new System.Drawing.Size(152, 37);
            this.comboActionTypeLog.Sorted = true;
            this.comboActionTypeLog.TabIndex = 61;
            this.comboActionTypeLog.SelectedIndexChanged += new System.EventHandler(this.comboActionTypeLog_SelectedIndexChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label32.Location = new System.Drawing.Point(167, 107);
            this.label32.Name = "label32";
            this.label32.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label32.Size = new System.Drawing.Size(97, 29);
            this.label32.TabIndex = 60;
            this.label32.Text = "نوع عملیات :";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label31.Location = new System.Drawing.Point(192, 59);
            this.label31.Name = "label31";
            this.label31.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label31.Size = new System.Drawing.Size(68, 29);
            this.label31.TabIndex = 58;
            this.label31.Text = "نام کالا :";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label30.Location = new System.Drawing.Point(192, 11);
            this.label30.Name = "label30";
            this.label30.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label30.Size = new System.Drawing.Size(67, 29);
            this.label30.TabIndex = 56;
            this.label30.Text = "کد کالا :";
            // 
            // txtDateEndLog
            // 
            this.txtDateEndLog.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtDateEndLog.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtDateEndLog.Location = new System.Drawing.Point(12, 198);
            this.txtDateEndLog.Name = "txtDateEndLog";
            this.txtDateEndLog.Size = new System.Drawing.Size(152, 36);
            this.txtDateEndLog.TabIndex = 55;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label28.Location = new System.Drawing.Point(169, 199);
            this.label28.Name = "label28";
            this.label28.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label28.Size = new System.Drawing.Size(93, 29);
            this.label28.TabIndex = 54;
            this.label28.Text = "تاریخ پایان :";
            // 
            // txtDateStartLog
            // 
            this.txtDateStartLog.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtDateStartLog.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtDateStartLog.Location = new System.Drawing.Point(12, 151);
            this.txtDateStartLog.Name = "txtDateStartLog";
            this.txtDateStartLog.Size = new System.Drawing.Size(152, 36);
            this.txtDateStartLog.TabIndex = 53;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label29.Location = new System.Drawing.Point(165, 156);
            this.label29.Name = "label29";
            this.label29.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label29.Size = new System.Drawing.Size(99, 29);
            this.label29.TabIndex = 52;
            this.label29.Text = "تاریخ شروع :";
            // 
            // dataGridViewLog
            // 
            this.dataGridViewLog.AutoGenerateColumns = false;
            this.dataGridViewLog.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.idOfGoodDataGridViewTextBoxColumn,
            this.nameOfGoodDataGridViewTextBoxColumn,
            this.typeOfActionDataGridViewTextBoxColumn,
            this.dateOfActionDataGridViewTextBoxColumn});
            this.dataGridViewLog.DataSource = this.logOfGoodsBindingSource;
            this.dataGridViewLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewLog.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewLog.Name = "dataGridViewLog";
            this.dataGridViewLog.Size = new System.Drawing.Size(526, 346);
            this.dataGridViewLog.TabIndex = 0;
            // 
            // tabFactorTable
            // 
            this.tabFactorTable.Controls.Add(this.splitContainer2);
            this.tabFactorTable.Location = new System.Drawing.Point(4, 39);
            this.tabFactorTable.Name = "tabFactorTable";
            this.tabFactorTable.Padding = new System.Windows.Forms.Padding(3);
            this.tabFactorTable.Size = new System.Drawing.Size(801, 352);
            this.tabFactorTable.TabIndex = 1;
            this.tabFactorTable.Text = "جدول فاکتور";
            this.tabFactorTable.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(3, 3);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.txtCustomerIdFactorTable);
            this.splitContainer2.Panel1.Controls.Add(this.txtFactorIdFactorTable);
            this.splitContainer2.Panel1.Controls.Add(this.btnClearFactorTable);
            this.splitContainer2.Panel1.Controls.Add(this.btnSearchAllFactorTable);
            this.splitContainer2.Panel1.Controls.Add(this.btnSearchDateFactorTable);
            this.splitContainer2.Panel1.Controls.Add(this.label33);
            this.splitContainer2.Panel1.Controls.Add(this.label34);
            this.splitContainer2.Panel1.Controls.Add(this.txtDateEndFactorTable);
            this.splitContainer2.Panel1.Controls.Add(this.label35);
            this.splitContainer2.Panel1.Controls.Add(this.txtDateStartFactorTable);
            this.splitContainer2.Panel1.Controls.Add(this.label36);
            this.splitContainer2.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.dataGridViewFactorTable);
            this.splitContainer2.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer2.Size = new System.Drawing.Size(795, 346);
            this.splitContainer2.SplitterDistance = 265;
            this.splitContainer2.TabIndex = 1;
            // 
            // txtCustomerIdFactorTable
            // 
            this.txtCustomerIdFactorTable.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCustomerIdFactorTable.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtCustomerIdFactorTable.Location = new System.Drawing.Point(8, 81);
            this.txtCustomerIdFactorTable.Name = "txtCustomerIdFactorTable";
            this.txtCustomerIdFactorTable.Size = new System.Drawing.Size(152, 36);
            this.txtCustomerIdFactorTable.TabIndex = 76;
            this.txtCustomerIdFactorTable.TextChanged += new System.EventHandler(this.txtCustomerIdFactorTable_TextChanged);
            // 
            // txtFactorIdFactorTable
            // 
            this.txtFactorIdFactorTable.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtFactorIdFactorTable.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtFactorIdFactorTable.Location = new System.Drawing.Point(8, 22);
            this.txtFactorIdFactorTable.Name = "txtFactorIdFactorTable";
            this.txtFactorIdFactorTable.Size = new System.Drawing.Size(152, 36);
            this.txtFactorIdFactorTable.TabIndex = 75;
            this.txtFactorIdFactorTable.TextChanged += new System.EventHandler(this.txtFactorIdFactorTable_TextChanged);
            // 
            // btnClearFactorTable
            // 
            this.btnClearFactorTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnClearFactorTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClearFactorTable.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnClearFactorTable.ForeColor = System.Drawing.Color.White;
            this.btnClearFactorTable.Location = new System.Drawing.Point(8, 301);
            this.btnClearFactorTable.Name = "btnClearFactorTable";
            this.btnClearFactorTable.Size = new System.Drawing.Size(247, 36);
            this.btnClearFactorTable.TabIndex = 74;
            this.btnClearFactorTable.Text = "پاک کردن ";
            this.btnClearFactorTable.UseVisualStyleBackColor = false;
            this.btnClearFactorTable.Click += new System.EventHandler(this.btnClearFactorTable_Click);
            // 
            // btnSearchAllFactorTable
            // 
            this.btnSearchAllFactorTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSearchAllFactorTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearchAllFactorTable.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSearchAllFactorTable.ForeColor = System.Drawing.Color.White;
            this.btnSearchAllFactorTable.Location = new System.Drawing.Point(8, 255);
            this.btnSearchAllFactorTable.Name = "btnSearchAllFactorTable";
            this.btnSearchAllFactorTable.Size = new System.Drawing.Size(115, 36);
            this.btnSearchAllFactorTable.TabIndex = 73;
            this.btnSearchAllFactorTable.Text = "جستجو ترکیبی";
            this.btnSearchAllFactorTable.UseVisualStyleBackColor = false;
            this.btnSearchAllFactorTable.Click += new System.EventHandler(this.btnSearchAllFactorTable_Click);
            // 
            // btnSearchDateFactorTable
            // 
            this.btnSearchDateFactorTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSearchDateFactorTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearchDateFactorTable.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSearchDateFactorTable.ForeColor = System.Drawing.Color.White;
            this.btnSearchDateFactorTable.Location = new System.Drawing.Point(140, 255);
            this.btnSearchDateFactorTable.Name = "btnSearchDateFactorTable";
            this.btnSearchDateFactorTable.Size = new System.Drawing.Size(115, 36);
            this.btnSearchDateFactorTable.TabIndex = 72;
            this.btnSearchDateFactorTable.Text = "جستجو تاریخ";
            this.btnSearchDateFactorTable.UseVisualStyleBackColor = false;
            this.btnSearchDateFactorTable.Click += new System.EventHandler(this.btnSearchDateFactorTable_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label33.Location = new System.Drawing.Point(164, 83);
            this.label33.Name = "label33";
            this.label33.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label33.Size = new System.Drawing.Size(94, 29);
            this.label33.TabIndex = 69;
            this.label33.Text = "کد مشتری :";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label34.Location = new System.Drawing.Point(170, 24);
            this.label34.Name = "label34";
            this.label34.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label34.Size = new System.Drawing.Size(88, 29);
            this.label34.TabIndex = 67;
            this.label34.Text = "کد فاکتور :";
            // 
            // txtDateEndFactorTable
            // 
            this.txtDateEndFactorTable.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtDateEndFactorTable.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtDateEndFactorTable.Location = new System.Drawing.Point(8, 193);
            this.txtDateEndFactorTable.Name = "txtDateEndFactorTable";
            this.txtDateEndFactorTable.Size = new System.Drawing.Size(152, 36);
            this.txtDateEndFactorTable.TabIndex = 66;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label35.Location = new System.Drawing.Point(165, 194);
            this.label35.Name = "label35";
            this.label35.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label35.Size = new System.Drawing.Size(93, 29);
            this.label35.TabIndex = 65;
            this.label35.Text = "تاریخ پایان :";
            // 
            // txtDateStartFactorTable
            // 
            this.txtDateStartFactorTable.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtDateStartFactorTable.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtDateStartFactorTable.Location = new System.Drawing.Point(8, 136);
            this.txtDateStartFactorTable.Name = "txtDateStartFactorTable";
            this.txtDateStartFactorTable.Size = new System.Drawing.Size(152, 36);
            this.txtDateStartFactorTable.TabIndex = 64;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label36.Location = new System.Drawing.Point(161, 141);
            this.label36.Name = "label36";
            this.label36.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label36.Size = new System.Drawing.Size(99, 29);
            this.label36.TabIndex = 63;
            this.label36.Text = "تاریخ شروع :";
            // 
            // dataGridViewFactorTable
            // 
            this.dataGridViewFactorTable.AutoGenerateColumns = false;
            this.dataGridViewFactorTable.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewFactorTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFactorTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.factorIDDataGridViewTextBoxColumn,
            this.coustomerIDDataGridViewTextBoxColumn,
            this.factorDateDataGridViewTextBoxColumn});
            this.dataGridViewFactorTable.DataSource = this.factorBindingSource;
            this.dataGridViewFactorTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewFactorTable.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewFactorTable.Name = "dataGridViewFactorTable";
            this.dataGridViewFactorTable.Size = new System.Drawing.Size(526, 346);
            this.dataGridViewFactorTable.TabIndex = 0;
            // 
            // tabRegisterFactor
            // 
            this.tabRegisterFactor.Controls.Add(this.splitContainer3);
            this.tabRegisterFactor.Location = new System.Drawing.Point(4, 39);
            this.tabRegisterFactor.Name = "tabRegisterFactor";
            this.tabRegisterFactor.Padding = new System.Windows.Forms.Padding(3);
            this.tabRegisterFactor.Size = new System.Drawing.Size(801, 352);
            this.tabRegisterFactor.TabIndex = 2;
            this.tabRegisterFactor.Text = "جدول فاکتور نهایی";
            this.tabRegisterFactor.UseVisualStyleBackColor = true;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(3, 3);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.btnClearRegisterTable);
            this.splitContainer3.Panel1.Controls.Add(this.btnSearchAllRegisterTable);
            this.splitContainer3.Panel1.Controls.Add(this.btnSearchOffRegisterTable);
            this.splitContainer3.Panel1.Controls.Add(this.txtGoodIdRegisterTable);
            this.splitContainer3.Panel1.Controls.Add(this.txtFavtorIdRegisterTable);
            this.splitContainer3.Panel1.Controls.Add(this.label37);
            this.splitContainer3.Panel1.Controls.Add(this.label38);
            this.splitContainer3.Panel1.Controls.Add(this.txtEndOffRegisterTable);
            this.splitContainer3.Panel1.Controls.Add(this.label39);
            this.splitContainer3.Panel1.Controls.Add(this.txtStartOffRegisterTable);
            this.splitContainer3.Panel1.Controls.Add(this.label40);
            this.splitContainer3.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.dataGridViewRegisterFactor);
            this.splitContainer3.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer3.Size = new System.Drawing.Size(795, 346);
            this.splitContainer3.SplitterDistance = 286;
            this.splitContainer3.TabIndex = 1;
            // 
            // btnClearRegisterTable
            // 
            this.btnClearRegisterTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnClearRegisterTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClearRegisterTable.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnClearRegisterTable.ForeColor = System.Drawing.Color.White;
            this.btnClearRegisterTable.Location = new System.Drawing.Point(9, 297);
            this.btnClearRegisterTable.Name = "btnClearRegisterTable";
            this.btnClearRegisterTable.Size = new System.Drawing.Size(264, 36);
            this.btnClearRegisterTable.TabIndex = 85;
            this.btnClearRegisterTable.Text = "پاک کردن ";
            this.btnClearRegisterTable.UseVisualStyleBackColor = false;
            this.btnClearRegisterTable.Click += new System.EventHandler(this.btnClearRegisterTable_Click);
            // 
            // btnSearchAllRegisterTable
            // 
            this.btnSearchAllRegisterTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSearchAllRegisterTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearchAllRegisterTable.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSearchAllRegisterTable.ForeColor = System.Drawing.Color.White;
            this.btnSearchAllRegisterTable.Location = new System.Drawing.Point(9, 251);
            this.btnSearchAllRegisterTable.Name = "btnSearchAllRegisterTable";
            this.btnSearchAllRegisterTable.Size = new System.Drawing.Size(125, 36);
            this.btnSearchAllRegisterTable.TabIndex = 84;
            this.btnSearchAllRegisterTable.Text = "جستجو ترکیبی";
            this.btnSearchAllRegisterTable.UseVisualStyleBackColor = false;
            this.btnSearchAllRegisterTable.Click += new System.EventHandler(this.btnSearchAllRegisterTable_Click);
            // 
            // btnSearchOffRegisterTable
            // 
            this.btnSearchOffRegisterTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSearchOffRegisterTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearchOffRegisterTable.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSearchOffRegisterTable.ForeColor = System.Drawing.Color.White;
            this.btnSearchOffRegisterTable.Location = new System.Drawing.Point(148, 251);
            this.btnSearchOffRegisterTable.Name = "btnSearchOffRegisterTable";
            this.btnSearchOffRegisterTable.Size = new System.Drawing.Size(125, 36);
            this.btnSearchOffRegisterTable.TabIndex = 83;
            this.btnSearchOffRegisterTable.Text = "جستجو تخفیف";
            this.btnSearchOffRegisterTable.UseVisualStyleBackColor = false;
            this.btnSearchOffRegisterTable.Click += new System.EventHandler(this.btnSearchOffRegisterTable_Click);
            // 
            // txtGoodIdRegisterTable
            // 
            this.txtGoodIdRegisterTable.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtGoodIdRegisterTable.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtGoodIdRegisterTable.Location = new System.Drawing.Point(9, 76);
            this.txtGoodIdRegisterTable.Name = "txtGoodIdRegisterTable";
            this.txtGoodIdRegisterTable.Size = new System.Drawing.Size(152, 36);
            this.txtGoodIdRegisterTable.TabIndex = 82;
            this.txtGoodIdRegisterTable.TextChanged += new System.EventHandler(this.txtGoodIdRegisterTable_TextChanged);
            // 
            // txtFavtorIdRegisterTable
            // 
            this.txtFavtorIdRegisterTable.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtFavtorIdRegisterTable.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtFavtorIdRegisterTable.Location = new System.Drawing.Point(9, 17);
            this.txtFavtorIdRegisterTable.Name = "txtFavtorIdRegisterTable";
            this.txtFavtorIdRegisterTable.Size = new System.Drawing.Size(152, 36);
            this.txtFavtorIdRegisterTable.TabIndex = 81;
            this.txtFavtorIdRegisterTable.TextChanged += new System.EventHandler(this.txtFavtorIdRegisterTable_TextChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label37.Location = new System.Drawing.Point(211, 76);
            this.label37.Name = "label37";
            this.label37.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label37.Size = new System.Drawing.Size(67, 29);
            this.label37.TabIndex = 78;
            this.label37.Text = "کد کالا :";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label38.Location = new System.Drawing.Point(190, 23);
            this.label38.Name = "label38";
            this.label38.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label38.Size = new System.Drawing.Size(88, 29);
            this.label38.TabIndex = 76;
            this.label38.Text = "کد فاکتور :";
            // 
            // txtEndOffRegisterTable
            // 
            this.txtEndOffRegisterTable.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtEndOffRegisterTable.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtEndOffRegisterTable.Location = new System.Drawing.Point(9, 194);
            this.txtEndOffRegisterTable.Name = "txtEndOffRegisterTable";
            this.txtEndOffRegisterTable.Size = new System.Drawing.Size(152, 36);
            this.txtEndOffRegisterTable.TabIndex = 75;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label39.Location = new System.Drawing.Point(157, 196);
            this.label39.Name = "label39";
            this.label39.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label39.Size = new System.Drawing.Size(121, 29);
            this.label39.TabIndex = 74;
            this.label39.Text = "حداکثر تخفیف :";
            // 
            // txtStartOffRegisterTable
            // 
            this.txtStartOffRegisterTable.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtStartOffRegisterTable.Font = new System.Drawing.Font("B Nazanin", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtStartOffRegisterTable.Location = new System.Drawing.Point(9, 136);
            this.txtStartOffRegisterTable.Name = "txtStartOffRegisterTable";
            this.txtStartOffRegisterTable.Size = new System.Drawing.Size(152, 36);
            this.txtStartOffRegisterTable.TabIndex = 73;
            this.txtStartOffRegisterTable.TextChanged += new System.EventHandler(this.txtStartOffRegisterTable_TextChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label40.Location = new System.Drawing.Point(161, 138);
            this.label40.Name = "label40";
            this.label40.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label40.Size = new System.Drawing.Size(119, 29);
            this.label40.TabIndex = 72;
            this.label40.Text = "حداقل تخفیف :";
            // 
            // dataGridViewRegisterFactor
            // 
            this.dataGridViewRegisterFactor.AutoGenerateColumns = false;
            this.dataGridViewRegisterFactor.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewRegisterFactor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRegisterFactor.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.factorIDDataGridViewTextBoxColumn1,
            this.goodsIDDataGridViewTextBoxColumn1,
            this.amountDataGridViewTextBoxColumn,
            this.discountValueDataGridViewTextBoxColumn,
            this.amountAfterDiscountDataGridViewTextBoxColumn});
            this.dataGridViewRegisterFactor.DataSource = this.registerFactorBindingSource;
            this.dataGridViewRegisterFactor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewRegisterFactor.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewRegisterFactor.Name = "dataGridViewRegisterFactor";
            this.dataGridViewRegisterFactor.Size = new System.Drawing.Size(505, 346);
            this.dataGridViewRegisterFactor.TabIndex = 0;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox3.Image = global::ShopDB.Properties.Resources.Reports;
            this.pictureBox3.Location = new System.Drawing.Point(3, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(840, 467);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::ShopDB.Properties.Resources.exit;
            this.pictureBox2.Location = new System.Drawing.Point(3, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 29);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 49;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // fKFactorCustomersBindingSource
            // 
            this.fKFactorCustomersBindingSource.DataMember = "FK_Factor_Customers";
            this.fKFactorCustomersBindingSource.DataSource = this.customersBindingSource;
            // 
            // fKFactorCustomersBindingSource1
            // 
            this.fKFactorCustomersBindingSource1.DataMember = "FK_Factor_Customers";
            this.fKFactorCustomersBindingSource1.DataSource = this.customersBindingSource;
            // 
            // goodsIDDataGridViewTextBoxColumn
            // 
            this.goodsIDDataGridViewTextBoxColumn.DataPropertyName = "GoodsID";
            this.goodsIDDataGridViewTextBoxColumn.HeaderText = "کد کالا";
            this.goodsIDDataGridViewTextBoxColumn.Name = "goodsIDDataGridViewTextBoxColumn";
            this.goodsIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // goodsNameDataGridViewTextBoxColumn
            // 
            this.goodsNameDataGridViewTextBoxColumn.DataPropertyName = "GoodsName";
            this.goodsNameDataGridViewTextBoxColumn.HeaderText = "نام کالا";
            this.goodsNameDataGridViewTextBoxColumn.Name = "goodsNameDataGridViewTextBoxColumn";
            // 
            // goodsUnitPriceDataGridViewTextBoxColumn
            // 
            this.goodsUnitPriceDataGridViewTextBoxColumn.DataPropertyName = "GoodsUnitPrice";
            this.goodsUnitPriceDataGridViewTextBoxColumn.HeaderText = "قیمت واحد(ریال)";
            this.goodsUnitPriceDataGridViewTextBoxColumn.Name = "goodsUnitPriceDataGridViewTextBoxColumn";
            // 
            // goodsStockDataGridViewTextBoxColumn
            // 
            this.goodsStockDataGridViewTextBoxColumn.DataPropertyName = "GoodsStock";
            this.goodsStockDataGridViewTextBoxColumn.HeaderText = "موجودی";
            this.goodsStockDataGridViewTextBoxColumn.Name = "goodsStockDataGridViewTextBoxColumn";
            // 
            // goodsBindingSource
            // 
            this.goodsBindingSource.DataMember = "Goods";
            this.goodsBindingSource.DataSource = this.shopDBDataSet;
            // 
            // shopDBDataSet
            // 
            this.shopDBDataSet.DataSetName = "ShopDBDataSet";
            this.shopDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerIDDataGridViewTextBoxColumn
            // 
            this.customerIDDataGridViewTextBoxColumn.DataPropertyName = "CustomerID";
            this.customerIDDataGridViewTextBoxColumn.FillWeight = 40F;
            this.customerIDDataGridViewTextBoxColumn.HeaderText = "کد";
            this.customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
            this.customerIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.customerIDDataGridViewTextBoxColumn.Width = 40;
            // 
            // customerNameDataGridViewTextBoxColumn
            // 
            this.customerNameDataGridViewTextBoxColumn.DataPropertyName = "CustomerName";
            this.customerNameDataGridViewTextBoxColumn.FillWeight = 80F;
            this.customerNameDataGridViewTextBoxColumn.HeaderText = "نام";
            this.customerNameDataGridViewTextBoxColumn.Name = "customerNameDataGridViewTextBoxColumn";
            this.customerNameDataGridViewTextBoxColumn.Width = 80;
            // 
            // customerFamilyDataGridViewTextBoxColumn
            // 
            this.customerFamilyDataGridViewTextBoxColumn.DataPropertyName = "CustomerFamily";
            this.customerFamilyDataGridViewTextBoxColumn.FillWeight = 87F;
            this.customerFamilyDataGridViewTextBoxColumn.HeaderText = "نام خانوداگی";
            this.customerFamilyDataGridViewTextBoxColumn.Name = "customerFamilyDataGridViewTextBoxColumn";
            this.customerFamilyDataGridViewTextBoxColumn.Width = 87;
            // 
            // customerPhoneDataGridViewTextBoxColumn
            // 
            this.customerPhoneDataGridViewTextBoxColumn.DataPropertyName = "CustomerPhone";
            this.customerPhoneDataGridViewTextBoxColumn.FillWeight = 80F;
            this.customerPhoneDataGridViewTextBoxColumn.HeaderText = "تلفن";
            this.customerPhoneDataGridViewTextBoxColumn.Name = "customerPhoneDataGridViewTextBoxColumn";
            this.customerPhoneDataGridViewTextBoxColumn.Width = 80;
            // 
            // customerBirthdayDataGridViewTextBoxColumn
            // 
            this.customerBirthdayDataGridViewTextBoxColumn.DataPropertyName = "CustomerBirthday";
            this.customerBirthdayDataGridViewTextBoxColumn.FillWeight = 70F;
            this.customerBirthdayDataGridViewTextBoxColumn.HeaderText = "تاریخ تولد";
            this.customerBirthdayDataGridViewTextBoxColumn.Name = "customerBirthdayDataGridViewTextBoxColumn";
            this.customerBirthdayDataGridViewTextBoxColumn.Width = 70;
            // 
            // customerAgeDataGridViewTextBoxColumn
            // 
            this.customerAgeDataGridViewTextBoxColumn.DataPropertyName = "CustomerAge";
            this.customerAgeDataGridViewTextBoxColumn.FillWeight = 40F;
            this.customerAgeDataGridViewTextBoxColumn.HeaderText = "سن";
            this.customerAgeDataGridViewTextBoxColumn.Name = "customerAgeDataGridViewTextBoxColumn";
            this.customerAgeDataGridViewTextBoxColumn.Width = 40;
            // 
            // customersBindingSource
            // 
            this.customersBindingSource.DataMember = "Customers";
            this.customersBindingSource.DataSource = this.shopDBDataSet;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.FillWeight = 80F;
            this.idDataGridViewTextBoxColumn.HeaderText = "کد لاگ";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 80;
            // 
            // idOfGoodDataGridViewTextBoxColumn
            // 
            this.idOfGoodDataGridViewTextBoxColumn.DataPropertyName = "idOfGood";
            this.idOfGoodDataGridViewTextBoxColumn.HeaderText = "کد کالا";
            this.idOfGoodDataGridViewTextBoxColumn.Name = "idOfGoodDataGridViewTextBoxColumn";
            // 
            // nameOfGoodDataGridViewTextBoxColumn
            // 
            this.nameOfGoodDataGridViewTextBoxColumn.DataPropertyName = "nameOfGood";
            this.nameOfGoodDataGridViewTextBoxColumn.HeaderText = "نام کالا";
            this.nameOfGoodDataGridViewTextBoxColumn.Name = "nameOfGoodDataGridViewTextBoxColumn";
            // 
            // typeOfActionDataGridViewTextBoxColumn
            // 
            this.typeOfActionDataGridViewTextBoxColumn.DataPropertyName = "typeOfAction";
            this.typeOfActionDataGridViewTextBoxColumn.HeaderText = "نوع عملیات";
            this.typeOfActionDataGridViewTextBoxColumn.Name = "typeOfActionDataGridViewTextBoxColumn";
            // 
            // dateOfActionDataGridViewTextBoxColumn
            // 
            this.dateOfActionDataGridViewTextBoxColumn.DataPropertyName = "dateOfAction";
            this.dateOfActionDataGridViewTextBoxColumn.HeaderText = "تاریخ عملیات";
            this.dateOfActionDataGridViewTextBoxColumn.Name = "dateOfActionDataGridViewTextBoxColumn";
            // 
            // logOfGoodsBindingSource
            // 
            this.logOfGoodsBindingSource.DataMember = "LogOfGoods";
            this.logOfGoodsBindingSource.DataSource = this.shopDBDataSet;
            // 
            // factorIDDataGridViewTextBoxColumn
            // 
            this.factorIDDataGridViewTextBoxColumn.DataPropertyName = "FactorID";
            this.factorIDDataGridViewTextBoxColumn.FillWeight = 160F;
            this.factorIDDataGridViewTextBoxColumn.HeaderText = "کد فاکتور";
            this.factorIDDataGridViewTextBoxColumn.Name = "factorIDDataGridViewTextBoxColumn";
            this.factorIDDataGridViewTextBoxColumn.Width = 160;
            // 
            // coustomerIDDataGridViewTextBoxColumn
            // 
            this.coustomerIDDataGridViewTextBoxColumn.DataPropertyName = "CoustomerID";
            this.coustomerIDDataGridViewTextBoxColumn.FillWeight = 160F;
            this.coustomerIDDataGridViewTextBoxColumn.HeaderText = "کد مشتری";
            this.coustomerIDDataGridViewTextBoxColumn.Name = "coustomerIDDataGridViewTextBoxColumn";
            this.coustomerIDDataGridViewTextBoxColumn.Width = 160;
            // 
            // factorDateDataGridViewTextBoxColumn
            // 
            this.factorDateDataGridViewTextBoxColumn.DataPropertyName = "FactorDate";
            this.factorDateDataGridViewTextBoxColumn.FillWeight = 160F;
            this.factorDateDataGridViewTextBoxColumn.HeaderText = "تاریخ فاکتور";
            this.factorDateDataGridViewTextBoxColumn.Name = "factorDateDataGridViewTextBoxColumn";
            this.factorDateDataGridViewTextBoxColumn.Width = 160;
            // 
            // factorBindingSource
            // 
            this.factorBindingSource.DataMember = "Factor";
            this.factorBindingSource.DataSource = this.shopDBDataSet;
            // 
            // factorIDDataGridViewTextBoxColumn1
            // 
            this.factorIDDataGridViewTextBoxColumn1.DataPropertyName = "FactorID";
            this.factorIDDataGridViewTextBoxColumn1.FillWeight = 65F;
            this.factorIDDataGridViewTextBoxColumn1.HeaderText = "کد فاکتور";
            this.factorIDDataGridViewTextBoxColumn1.Name = "factorIDDataGridViewTextBoxColumn1";
            this.factorIDDataGridViewTextBoxColumn1.Width = 65;
            // 
            // goodsIDDataGridViewTextBoxColumn1
            // 
            this.goodsIDDataGridViewTextBoxColumn1.DataPropertyName = "GoodsID";
            this.goodsIDDataGridViewTextBoxColumn1.FillWeight = 90F;
            this.goodsIDDataGridViewTextBoxColumn1.HeaderText = "کد کالا";
            this.goodsIDDataGridViewTextBoxColumn1.Name = "goodsIDDataGridViewTextBoxColumn1";
            this.goodsIDDataGridViewTextBoxColumn1.Width = 90;
            // 
            // amountDataGridViewTextBoxColumn
            // 
            this.amountDataGridViewTextBoxColumn.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn.FillWeight = 90F;
            this.amountDataGridViewTextBoxColumn.HeaderText = "مبلغ پرداختی";
            this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            this.amountDataGridViewTextBoxColumn.Width = 90;
            // 
            // discountValueDataGridViewTextBoxColumn
            // 
            this.discountValueDataGridViewTextBoxColumn.DataPropertyName = "DiscountValue";
            this.discountValueDataGridViewTextBoxColumn.FillWeight = 75F;
            this.discountValueDataGridViewTextBoxColumn.HeaderText = "درصد تخفیف";
            this.discountValueDataGridViewTextBoxColumn.Name = "discountValueDataGridViewTextBoxColumn";
            this.discountValueDataGridViewTextBoxColumn.Width = 75;
            // 
            // amountAfterDiscountDataGridViewTextBoxColumn
            // 
            this.amountAfterDiscountDataGridViewTextBoxColumn.DataPropertyName = "AmountAfterDiscount";
            this.amountAfterDiscountDataGridViewTextBoxColumn.FillWeight = 140F;
            this.amountAfterDiscountDataGridViewTextBoxColumn.HeaderText = "مبلغ پرداختی پس از تخفیف";
            this.amountAfterDiscountDataGridViewTextBoxColumn.Name = "amountAfterDiscountDataGridViewTextBoxColumn";
            this.amountAfterDiscountDataGridViewTextBoxColumn.Width = 140;
            // 
            // registerFactorBindingSource
            // 
            this.registerFactorBindingSource.DataMember = "RegisterFactor";
            this.registerFactorBindingSource.DataSource = this.shopDBDataSet;
            // 
            // factorTableAdapter
            // 
            this.factorTableAdapter.ClearBeforeFill = true;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // goodsTableAdapter
            // 
            this.goodsTableAdapter.ClearBeforeFill = true;
            // 
            // registerFactorTableAdapter
            // 
            this.registerFactorTableAdapter.ClearBeforeFill = true;
            // 
            // logOfGoodsTableAdapter
            // 
            this.logOfGoodsTableAdapter.ClearBeforeFill = true;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ShopDB.Properties.Resources._1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(900, 553);
            this.ControlBox = false;
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.tabControl1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabFactors.ResumeLayout(false);
            this.tabFactors.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGoodTab)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCustomerTab)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFactor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabGoods.ResumeLayout(false);
            this.tabGoods.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGood)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.tabCustomers.ResumeLayout(false);
            this.tabCustomers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCustomers_Customer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.tabReports.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabLog.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLog)).EndInit();
            this.tabFactorTable.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFactorTable)).EndInit();
            this.tabRegisterFactor.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRegisterFactor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKFactorCustomersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKFactorCustomersBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logOfGoodsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.factorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.registerFactorBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabFactors;
        private System.Windows.Forms.TabPage tabGoods;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridViewFactor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboCustomerID_Factor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboGoodID_Factor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnInsertCart_Factor;
        private System.Windows.Forms.Button btnClear_Factor;
        private System.Windows.Forms.Button btnInsertFactorRegister_Factor;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox picCustomerTab;
        private System.Windows.Forms.TextBox txtCountGood_Factor;
        private System.Windows.Forms.TextBox txtDiscount_Factor;
        private System.Windows.Forms.PictureBox picGoodTab;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblCustomerPhone_Factor;
        private System.Windows.Forms.Label lblCutomerName_Factor;
        private System.Windows.Forms.Label lblFactorDate_Factor;
        private System.Windows.Forms.Label lblFactorID_Factor;
        private System.Windows.Forms.Label lblAmountAfter_Factor;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblAmount_Factor;
        private System.Windows.Forms.Label lblGoodUnitPrice_Factor;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TextBox txtGoodIDSearch_Good;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TextBox txtGoodNameSearch_Good;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button btnUpdateGood_Good;
        private System.Windows.Forms.Button btnInsertGood_Good;
        private System.Windows.Forms.TextBox txtGoodStocks_Good;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtGoodUnitPrice_Good;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtGoodName_Good;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtGoodID_Good;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnClear_Good;
        private System.Windows.Forms.Button btnInsertToGoodTab_Good;
        private System.Windows.Forms.Button btnDeleteGood_Good;
        private System.Windows.Forms.DataGridView dataGridViewGood;
        private System.Windows.Forms.TabPage tabCustomers;
        private System.Windows.Forms.TextBox txtCustomerBirthday_Customer;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.DataGridView dataGridViewCustomers_Customer;
        private System.Windows.Forms.Button btnDeleteCustomer_Customer;
        private System.Windows.Forms.Button btnClear_Customer;
        private System.Windows.Forms.Button btnUpdateCustomer_Customer;
        private System.Windows.Forms.Button btnInsertCustomer_Customer;
        private System.Windows.Forms.TextBox txtCustomerTel_Customer;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtCustomerLName_Customer;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtCustomerFName_Customer;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtCustomerID_Customer;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private ShopDBDataSet shopDBDataSet;
        private System.Windows.Forms.BindingSource factorBindingSource;
        private ShopDBDataSetTableAdapters.FactorTableAdapter factorTableAdapter;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private ShopDBDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
        private System.Windows.Forms.BindingSource goodsBindingSource;
        private ShopDBDataSetTableAdapters.GoodsTableAdapter goodsTableAdapter;
        private System.Windows.Forms.BindingSource registerFactorBindingSource;
        private ShopDBDataSetTableAdapters.RegisterFactorTableAdapter registerFactorTableAdapter;
        private System.Windows.Forms.Label lblGoodName_Factor;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodsIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodsNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodsUnitPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodsStockDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodName;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn AllCost;
        private System.Windows.Forms.DataGridViewImageColumn remove;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerFamilyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerPhoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerBirthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerAgeDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource fKFactorCustomersBindingSource;
        private System.Windows.Forms.BindingSource fKFactorCustomersBindingSource1;
        private System.Windows.Forms.Button btnInsertToFactorTab_Customer;
        private System.Windows.Forms.TextBox txtNameSearch_Customer;
        private System.Windows.Forms.TextBox txtIDSearch_Customer;
        private System.Windows.Forms.TabPage tabReports;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabLog;
        private System.Windows.Forms.DataGridView dataGridViewLog;
        private System.Windows.Forms.TabPage tabFactorTable;
        private System.Windows.Forms.TabPage tabRegisterFactor;
        private System.Windows.Forms.BindingSource logOfGoodsBindingSource;
        private ShopDBDataSetTableAdapters.LogOfGoodsTableAdapter logOfGoodsTableAdapter;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idOfGoodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameOfGoodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeOfActionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateOfActionDataGridViewTextBoxColumn;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.DataGridView dataGridViewFactorTable;
        private System.Windows.Forms.DataGridViewTextBoxColumn factorIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn coustomerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn factorDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.DataGridView dataGridViewRegisterFactor;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox txtDateEndLog;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtDateStartLog;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button btnSearchDateLog;
        private System.Windows.Forms.ComboBox comboActionTypeLog;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtDateEndFactorTable;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtDateStartFactorTable;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtEndOffRegisterTable;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtStartOffRegisterTable;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.DataGridViewTextBoxColumn factorIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodsIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn discountValueDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountAfterDiscountDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox txtGoodNameLog;
        private System.Windows.Forms.TextBox txtGoodIdLog;
        private System.Windows.Forms.Button btnSearchAllLog;
        private System.Windows.Forms.Button btnClearLog;
        private System.Windows.Forms.Button btnClearFactorTable;
        private System.Windows.Forms.Button btnSearchAllFactorTable;
        private System.Windows.Forms.Button btnSearchDateFactorTable;
        private System.Windows.Forms.TextBox txtCustomerIdFactorTable;
        private System.Windows.Forms.TextBox txtFactorIdFactorTable;
        private System.Windows.Forms.TextBox txtGoodIdRegisterTable;
        private System.Windows.Forms.TextBox txtFavtorIdRegisterTable;
        private System.Windows.Forms.Button btnClearRegisterTable;
        private System.Windows.Forms.Button btnSearchAllRegisterTable;
        private System.Windows.Forms.Button btnSearchOffRegisterTable;
    }
}