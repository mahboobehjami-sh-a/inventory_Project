﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopDB
{
    public partial class SignUp : Form
    {
        bool showPass = false;

        public SignUp()
        {
            InitializeComponent();
        }

        private void btnExitSignUp_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {

            if (txtUsernameSignUp.TextLength > 0 && txtPassSignUp.TextLength > 0)
            {
                bool isValidFields = true;
                if (txtPhoneSignUp.TextLength > 0)
                {
                    bool isLetterInPhone = false;
                    foreach (char c in txtPhoneSignUp.Text)
                    {
                        if (Char.IsLetter(c))
                        {
                            isValidFields = false;
                            isLetterInPhone = true;
                        }
                    }

                    if (isLetterInPhone)
                    {
                        string msgphoneField = "شماره تلفن همراه نمی تواند شامل حروف باشد";
                        MessageBox.Show(msgphoneField, "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                    if (txtPhoneSignUp.TextLength < 11)
                    {
                        isValidFields = false;
                        string msgphoneField = "شماره تلفن کمتر از 11 کاراکتر است";
                        MessageBox.Show(msgphoneField, "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }

                if (txtPassSignUp.TextLength < 6)
                {
                    isValidFields = false;
                    string msgPassField = "رمز عبور کمتر از 6 کاراکتر است";
                    MessageBox.Show(msgPassField, "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                if (isValidFields)
                {
                    usersTableAdapter.InsertQuery(txtUsernameSignUp.Text, txtPassSignUp.Text, txtFNameSignUp.Text, txtLNameSignUp.Text, txtPhoneSignUp.Text);
                    Main frm = new Main();
                    frm.Show();
                    this.Hide();
                }
            }
            else
            {
                string msgEmptyField = " فیلد نام کاربری یا رمز عبور خالی می باشد";
                MessageBox.Show(msgEmptyField, "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


        }

        private void picStatePassSignUp_Click(object sender, EventArgs e)
        {
            if (!showPass)
            {
                picStatePassSignUp.Image = Image.FromFile(@"images/showPass.png");
                txtPassSignUp.PasswordChar = '\0';
                showPass = true;
            }
            else
            {
                picStatePassSignUp.Image = Image.FromFile(@"images/hidePass.png");
                txtPassSignUp.PasswordChar = '*';
                showPass = false;
            }
        }

        private void SignUp_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'shopDBDataSet.Users' table. You can move, or remove it, as needed.
            this.usersTableAdapter.Fill(this.shopDBDataSet.Users);

        }
    }
}
