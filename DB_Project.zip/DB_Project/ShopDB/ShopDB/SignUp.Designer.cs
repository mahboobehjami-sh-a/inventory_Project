﻿namespace ShopDB
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLNameSignUp = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFNameSignUp = new System.Windows.Forms.TextBox();
            this.picStatePassSignUp = new System.Windows.Forms.PictureBox();
            this.btnExitSignUp = new System.Windows.Forms.Button();
            this.btnSignUp = new System.Windows.Forms.Button();
            this.lblPassSignUp = new System.Windows.Forms.Label();
            this.lblUserNameSignUp = new System.Windows.Forms.Label();
            this.txtUsernameSignUp = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtPhoneSignUp = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPassSignUp = new System.Windows.Forms.TextBox();
            this.shopDBDataSet = new ShopDB.ShopDBDataSet();
            this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.usersTableAdapter = new ShopDB.ShopDBDataSetTableAdapters.UsersTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.picStatePassSignUp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.Location = new System.Drawing.Point(484, 162);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(98, 29);
            this.label3.TabIndex = 33;
            this.label3.Text = "نام خانوادگی";
            // 
            // txtLNameSignUp
            // 
            this.txtLNameSignUp.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtLNameSignUp.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtLNameSignUp.Location = new System.Drawing.Point(224, 162);
            this.txtLNameSignUp.Name = "txtLNameSignUp";
            this.txtLNameSignUp.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtLNameSignUp.Size = new System.Drawing.Size(246, 36);
            this.txtLNameSignUp.TabIndex = 32;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Location = new System.Drawing.Point(549, 104);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(33, 29);
            this.label2.TabIndex = 31;
            this.label2.Text = "نام";
            // 
            // txtFNameSignUp
            // 
            this.txtFNameSignUp.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtFNameSignUp.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtFNameSignUp.Location = new System.Drawing.Point(224, 104);
            this.txtFNameSignUp.Name = "txtFNameSignUp";
            this.txtFNameSignUp.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtFNameSignUp.Size = new System.Drawing.Size(246, 36);
            this.txtFNameSignUp.TabIndex = 30;
            // 
            // picStatePassSignUp
            // 
            this.picStatePassSignUp.BackColor = System.Drawing.Color.WhiteSmoke;
            this.picStatePassSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picStatePassSignUp.Image = global::ShopDB.Properties.Resources.hidePass;
            this.picStatePassSignUp.Location = new System.Drawing.Point(226, 291);
            this.picStatePassSignUp.Name = "picStatePassSignUp";
            this.picStatePassSignUp.Size = new System.Drawing.Size(26, 17);
            this.picStatePassSignUp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picStatePassSignUp.TabIndex = 29;
            this.picStatePassSignUp.TabStop = false;
            this.picStatePassSignUp.Click += new System.EventHandler(this.picStatePassSignUp_Click);
            // 
            // btnExitSignUp
            // 
            this.btnExitSignUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnExitSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExitSignUp.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnExitSignUp.ForeColor = System.Drawing.Color.White;
            this.btnExitSignUp.Location = new System.Drawing.Point(224, 419);
            this.btnExitSignUp.Name = "btnExitSignUp";
            this.btnExitSignUp.Size = new System.Drawing.Size(114, 36);
            this.btnExitSignUp.TabIndex = 28;
            this.btnExitSignUp.Text = "خروج";
            this.btnExitSignUp.UseVisualStyleBackColor = false;
            this.btnExitSignUp.Click += new System.EventHandler(this.btnExitSignUp_Click);
            // 
            // btnSignUp
            // 
            this.btnSignUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSignUp.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSignUp.ForeColor = System.Drawing.Color.White;
            this.btnSignUp.Location = new System.Drawing.Point(463, 419);
            this.btnSignUp.Name = "btnSignUp";
            this.btnSignUp.Size = new System.Drawing.Size(114, 36);
            this.btnSignUp.TabIndex = 27;
            this.btnSignUp.Text = "ثبت نام";
            this.btnSignUp.UseVisualStyleBackColor = false;
            this.btnSignUp.Click += new System.EventHandler(this.btnSignUp_Click);
            // 
            // lblPassSignUp
            // 
            this.lblPassSignUp.AutoSize = true;
            this.lblPassSignUp.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblPassSignUp.Location = new System.Drawing.Point(504, 282);
            this.lblPassSignUp.Name = "lblPassSignUp";
            this.lblPassSignUp.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblPassSignUp.Size = new System.Drawing.Size(78, 29);
            this.lblPassSignUp.TabIndex = 26;
            this.lblPassSignUp.Text = "رمز عبور*";
            // 
            // lblUserNameSignUp
            // 
            this.lblUserNameSignUp.AutoSize = true;
            this.lblUserNameSignUp.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblUserNameSignUp.Location = new System.Drawing.Point(494, 222);
            this.lblUserNameSignUp.Name = "lblUserNameSignUp";
            this.lblUserNameSignUp.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblUserNameSignUp.Size = new System.Drawing.Size(88, 29);
            this.lblUserNameSignUp.TabIndex = 25;
            this.lblUserNameSignUp.Text = "نام کاربری*";
            // 
            // txtUsernameSignUp
            // 
            this.txtUsernameSignUp.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtUsernameSignUp.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtUsernameSignUp.Location = new System.Drawing.Point(224, 222);
            this.txtUsernameSignUp.Name = "txtUsernameSignUp";
            this.txtUsernameSignUp.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtUsernameSignUp.Size = new System.Drawing.Size(246, 36);
            this.txtUsernameSignUp.TabIndex = 23;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::ShopDB.Properties.Resources.Register;
            this.pictureBox1.Location = new System.Drawing.Point(179, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(427, 470);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // txtPhoneSignUp
            // 
            this.txtPhoneSignUp.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtPhoneSignUp.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtPhoneSignUp.Location = new System.Drawing.Point(224, 341);
            this.txtPhoneSignUp.Name = "txtPhoneSignUp";
            this.txtPhoneSignUp.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtPhoneSignUp.Size = new System.Drawing.Size(246, 36);
            this.txtPhoneSignUp.TabIndex = 34;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.Location = new System.Drawing.Point(484, 348);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label4.Size = new System.Drawing.Size(98, 29);
            this.label4.TabIndex = 35;
            this.label4.Text = "شماره همراه";
            // 
            // txtPassSignUp
            // 
            this.txtPassSignUp.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtPassSignUp.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtPassSignUp.Location = new System.Drawing.Point(224, 282);
            this.txtPassSignUp.Name = "txtPassSignUp";
            this.txtPassSignUp.PasswordChar = '*';
            this.txtPassSignUp.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtPassSignUp.Size = new System.Drawing.Size(246, 36);
            this.txtPassSignUp.TabIndex = 24;
            // 
            // shopDBDataSet
            // 
            this.shopDBDataSet.DataSetName = "ShopDBDataSet";
            this.shopDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // usersBindingSource
            // 
            this.usersBindingSource.DataMember = "Users";
            this.usersBindingSource.DataSource = this.shopDBDataSet;
            // 
            // usersTableAdapter
            // 
            this.usersTableAdapter.ClearBeforeFill = true;
            // 
            // SignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ShopDB.Properties.Resources._1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 500);
            this.ControlBox = false;
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPhoneSignUp);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtLNameSignUp);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtFNameSignUp);
            this.Controls.Add(this.picStatePassSignUp);
            this.Controls.Add(this.btnExitSignUp);
            this.Controls.Add(this.btnSignUp);
            this.Controls.Add(this.lblPassSignUp);
            this.Controls.Add(this.lblUserNameSignUp);
            this.Controls.Add(this.txtPassSignUp);
            this.Controls.Add(this.txtUsernameSignUp);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SignUp";
            this.Text = "SignUp";
            this.Load += new System.EventHandler(this.SignUp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picStatePassSignUp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLNameSignUp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFNameSignUp;
        private System.Windows.Forms.PictureBox picStatePassSignUp;
        private System.Windows.Forms.Button btnExitSignUp;
        private System.Windows.Forms.Button btnSignUp;
        private System.Windows.Forms.Label lblPassSignUp;
        private System.Windows.Forms.Label lblUserNameSignUp;
        private System.Windows.Forms.TextBox txtUsernameSignUp;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtPhoneSignUp;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPassSignUp;
        private ShopDBDataSet shopDBDataSet;
        private System.Windows.Forms.BindingSource usersBindingSource;
        private ShopDBDataSetTableAdapters.UsersTableAdapter usersTableAdapter;
    }
}