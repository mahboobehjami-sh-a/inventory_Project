﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopDB
{
    public partial class SignIn : Form
    {
        bool showpass = false;
        public SignIn()
        {
            InitializeComponent();
        }

        private void SignIn_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'shopDBDataSet.Users' table. You can move, or remove it, as needed.
            this.usersTableAdapter.Fill(this.shopDBDataSet.Users);

        }

        private void btnExitSignIn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void picStatePassSignIn_Click(object sender, EventArgs e)
        {
            if (!showpass)
            {
                picStatePassSignIn.Image = Image.FromFile(@"images/showPass.png");
                txtPassSignIn.PasswordChar = '\0';
                showpass = true;
            }
            else
            {
                picStatePassSignIn.Image = Image.FromFile(@"images/hidePass.png");
                txtPassSignIn.PasswordChar = '*';
                showpass = false;
            }
        }

        private void lblGoToSignUp_Click(object sender, EventArgs e)
        {
            SignUp frm = new SignUp();
            frm.Show();
            this.Hide();
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            if (txtUsernameSignIn.TextLength > 0 && txtPassSignIn.TextLength > 0)
            {
                usersTableAdapter.FillByUsernamePass(shopDBDataSet.Users, txtUsernameSignIn.Text, txtPassSignIn.Text);
                if (shopDBDataSet.Users.Rows.Count > 0)
                {
                    Main frm = new Main();
                    frm.Show();
                    this.Hide();
                }
                else
                {
                    string msgLoginFailed = "کاربری با چنین نام کاربری و رمز عبور وجود ندارد";
                    MessageBox.Show(msgLoginFailed, "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtUsernameSignIn.Clear();
                    txtPassSignIn.Clear();
                }
            }
            else
            {
                string msgEmptyField = " فیلد نام کاربری یا رمز عبور خالی می باشد";
                MessageBox.Show(msgEmptyField, "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void lblGoToSignUp_DragOver(object sender, DragEventArgs e)
        {
        }
    }
}
