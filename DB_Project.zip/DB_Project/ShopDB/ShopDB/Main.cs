﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopDB
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        bool isAddToFactor;
        string currentCustomer, currentGood;
        string msg = "";

        private void Main_Load(object sender, EventArgs e)
        {

            // TODO: This line of code loads data into the 'shopDBDataSet.LogOfGoods' table. You can move, or remove it, as needed.
            this.logOfGoodsTableAdapter.Fill(this.shopDBDataSet.LogOfGoods);
            // TODO: This line of code loads data into the 'shopDBDataSet.RegisterFactor' table. You can move, or remove it, as needed.
            this.registerFactorTableAdapter.Fill(this.shopDBDataSet.RegisterFactor);
            // TODO: This line of code loads data into the 'shopDBDataSet.Goods' table. You can move, or remove it, as needed.
            this.goodsTableAdapter.Fill(this.shopDBDataSet.Goods);
            // TODO: This line of code loads data into the 'shopDBDataSet.Customers' table. You can move, or remove it, as needed.
            this.customersTableAdapter.Fill(this.shopDBDataSet.Customers);
            // TODO: This line of code loads data into the 'shopDBDataSet.Factor' table. You can move, or remove it, as needed.
            this.factorTableAdapter.Fill(this.shopDBDataSet.Factor);

            for (int i = 0; i < shopDBDataSet.Customers.Rows.Count; i++)
            {
                var item = shopDBDataSet.Customers.Rows[i]["CustomerID"].ToString();
                comboCustomerID_Factor.Items.Add(item);
            }

            for (int i = 0; i < shopDBDataSet.Goods.Rows.Count; i++)
            {
                var item = shopDBDataSet.Goods.Rows[i]["GoodsID"].ToString();
                comboGoodID_Factor.Items.Add(item);
                int goodStock = int.Parse(shopDBDataSet.Goods.Rows[i]["GoodsStock"].ToString());
                if (goodStock <= 10)
                {
                    msg += shopDBDataSet.Goods.Rows[i]["GoodsName"].ToString() + "  ,";
                }
            }
            MessageBox.Show(":موجودی کالا های زیر از 10 عدد کمتر شده است\n" + msg, "اطلاعیه", MessageBoxButtons.OK, MessageBoxIcon.None);


        }

        private void comboCustomerID_Factor_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectCustomerId = comboCustomerID_Factor.Text;
            customersTableAdapter.FillByID(shopDBDataSet.Customers, int.Parse(selectCustomerId));
            comboCustomerID_Factor.Text = shopDBDataSet.Customers.Rows[0]["CustomerID"].ToString();
            lblCutomerName_Factor.Text = shopDBDataSet.Customers.Rows[0]["CustomerName"].ToString() + "  " + shopDBDataSet.Customers.Rows[0]["CustomerFamily"].ToString();
            lblCustomerPhone_Factor.Text = shopDBDataSet.Customers.Rows[0]["CustomerPhone"].ToString();
            currentCustomer = comboCustomerID_Factor.Text;
        }

        private void comboGoodID_Factor_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedGoodId = comboGoodID_Factor.Text;
            goodsTableAdapter.FillByID(shopDBDataSet.Goods, int.Parse(selectedGoodId));
            lblGoodUnitPrice_Factor.Text = shopDBDataSet.Goods.Rows[0]["GoodsUnitPrice"].ToString();
            lblGoodName_Factor.Text = shopDBDataSet.Goods.Rows[0]["GoodsName"].ToString();
            comboGoodID_Factor.Text = shopDBDataSet.Goods.Rows[0]["GoodsID"].ToString();
            currentGood = comboGoodID_Factor.Text;

        }

        private void txtCountGood_Factor_TextChanged(object sender, EventArgs e)
        {


        }

        private void btnInsertCart_Factor_Click(object sender, EventArgs e)
        {
            int allAmount = 0;
            if (comboGoodID_Factor.Text.Length > 0 && txtCountGood_Factor.TextLength > 0 && comboCustomerID_Factor.Text.Length > 0)
            {
                goodsTableAdapter.FillByID(shopDBDataSet.Goods, int.Parse(currentGood));
                int goodStock = int.Parse(shopDBDataSet.Goods.Rows[0]["GoodsStock"].ToString());
                try
                {
                    if (int.Parse(txtCountGood_Factor.Text) > goodStock)
                    {
                        MessageBox.Show("تعداد کالای انتخابی از موجودی انبار کمتر است", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtCountGood_Factor.Clear();

                    }
                    else
                    {
                        int numOfSelectedGood = dataGridViewFactor.Rows.Count - 1;
                        dataGridViewFactor.Rows.Add();
                        dataGridViewFactor.Rows[numOfSelectedGood].Cells[0].Value = comboGoodID_Factor.Text;
                        dataGridViewFactor.Rows[numOfSelectedGood].Cells[1].Value = lblGoodName_Factor.Text;
                        dataGridViewFactor.Rows[numOfSelectedGood].Cells[2].Value = txtCountGood_Factor.Text;
                        dataGridViewFactor.Rows[numOfSelectedGood].Cells[3].Value = lblGoodUnitPrice_Factor.Text;
                        dataGridViewFactor.Rows[numOfSelectedGood].Cells[4].Value = int.Parse(txtCountGood_Factor.Text) * int.Parse(lblGoodUnitPrice_Factor.Text);
                        comboGoodID_Factor.ResetText();
                        lblGoodName_Factor.Text = "";
                        txtCountGood_Factor.Clear();
                        lblGoodUnitPrice_Factor.Text = "";
                    }
                }
                catch
                {
                    MessageBox.Show("فیلد تعداد باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtCountGood_Factor.Clear();
                }

            }
            else
            {
                txtCountGood_Factor.Clear();
                MessageBox.Show("کد کالا، تعداد کالا یا کد مشتری انتخاب نشده است", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            if (dataGridViewFactor.Rows.Count > 0)
            {
                for (int i = 0; i < dataGridViewFactor.Rows.Count - 1; i++)
                {
                    allAmount += int.Parse(dataGridViewFactor.Rows[i].Cells[4].Value.ToString());
                }
                lblAmount_Factor.Text = allAmount.ToString();
                isAddToFactor = false;
                if (txtDiscount_Factor.TextLength > 0)
                {
                    int discount = int.Parse(txtDiscount_Factor.Text);
                    int price = allAmount - ((allAmount * discount) / 100);
                    lblAmountAfter_Factor.Text = price.ToString();

                }
                else
                {
                    lblAmountAfter_Factor.Text = allAmount.ToString();
                }
            }

        }

        private void dataGridViewFactor_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewFactor.Columns[e.ColumnIndex] is DataGridViewImageColumn && e.RowIndex >= 0 && dataGridViewFactor.Rows.Count > 1)
            {
                dataGridViewFactor.Rows.RemoveAt(e.RowIndex);
            }
        }

        private void btnInsertFactorRegister_Factor_Click(object sender, EventArgs e)
        {
            if (!isAddToFactor&& dataGridViewFactor.Rows.Count > 1)
            {
                factorTableAdapter.InsertQuery(int.Parse(comboCustomerID_Factor.Text));
                factorTableAdapter.Fill(shopDBDataSet.Factor);
                int lastFactorId = 1;
                string lastFactorDate = DateTime.Now.ToShortDateString();
                if (shopDBDataSet.Factor.Rows.Count > 0)
                {
                    lastFactorId = int.Parse(shopDBDataSet.Factor.Rows[shopDBDataSet.Factor.Rows.Count - 1]["FactorID"].ToString());
                    lastFactorDate = shopDBDataSet.Factor.Rows[shopDBDataSet.Factor.Rows.Count - 1]["FactorDate"].ToString();
                }
                if (txtDiscount_Factor.TextLength > 0)
                {
                    registerFactorTableAdapter.InsertQuery(lastFactorId, int.Parse(currentGood), int.Parse(lblAmount_Factor.Text), int.Parse(txtDiscount_Factor.Text), float.Parse(lblAmountAfter_Factor.Text));
                }
                else
                {
                    registerFactorTableAdapter.InsertQuery2(lastFactorId, int.Parse(currentGood), float.Parse(lblAmount_Factor.Text));
                }
                lblFactorID_Factor.Text = lastFactorId.ToString();
                lblFactorDate_Factor.Text = lastFactorDate.ToString();
                isAddToFactor = true;

                int index = 0;
                int countOfFactorGood = dataGridViewFactor.Rows.Count;
                while (countOfFactorGood > 1)
                {
                    int goodId = int.Parse(dataGridViewFactor.Rows[index].Cells[0].Value.ToString());
                    goodsTableAdapter.FillByID(shopDBDataSet.Goods, goodId);
                    int goodStockFirst = int.Parse(shopDBDataSet.Goods.Rows[0]["GoodsStock"].ToString());
                    int goodStockSelected = int.Parse(dataGridViewFactor.Rows[index].Cells[2].Value.ToString());
                    int goodStockLast = goodStockFirst - goodStockSelected;
                    goodsTableAdapter.UpdateQueryGoodStock(goodStockLast, goodId);
                    countOfFactorGood--;
                    index++;
                }
                goodsTableAdapter.Fill(shopDBDataSet.Goods);
            }
        }

        private void btnClear_Factor_Click(object sender, EventArgs e)
        {
            while (dataGridViewFactor.Rows.Count > 1)
            {
                dataGridViewFactor.Rows.RemoveAt(0);

            }
            lblFactorID_Factor.Text = "";
            lblFactorDate_Factor.Text = "";
            comboCustomerID_Factor.ResetText();
            lblCutomerName_Factor.Text = "";
            lblCustomerPhone_Factor.Text = "";
            comboGoodID_Factor.ResetText();
            lblGoodName_Factor.Text = "";
            txtCountGood_Factor.Clear();
            lblGoodUnitPrice_Factor.Text = "";
            txtDiscount_Factor.Clear();
            lblAmountAfter_Factor.Text = "";
            lblAmount_Factor.Text = "";
            currentCustomer = "";
            currentGood = "";
        }

        private void picCustomerTab_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabCustomers;
        }

        private void picGoodTab_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabGoods;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtGoodIDSearch_Good_TextChanged(object sender, EventArgs e)
        {
            if (txtGoodIDSearch_Good.TextLength > 0)
            {
                try
                {
                    goodsTableAdapter.FillByID(shopDBDataSet.Goods, int.Parse(txtGoodIDSearch_Good.Text));

                    if (shopDBDataSet.Goods.Rows.Count > 0)
                    {
                        txtGoodNameSearch_Good.Text = shopDBDataSet.Goods.Rows[0]["GoodsName"].ToString();
                        txtGoodID_Good.Text = shopDBDataSet.Goods.Rows[0]["GoodsID"].ToString();
                        txtGoodName_Good.Text = shopDBDataSet.Goods.Rows[0]["GoodsName"].ToString();
                        txtGoodUnitPrice_Good.Text = shopDBDataSet.Goods.Rows[0]["GoodsUnitPrice"].ToString();
                        txtGoodStocks_Good.Text = shopDBDataSet.Goods.Rows[0]["GoodsStock"].ToString();
                    }
                }
                catch
                {
                    MessageBox.Show("فیلد کد کالا باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtGoodIDSearch_Good.Clear();
                }
            }
            else
            {
                txtGoodNameSearch_Good.Clear();
                goodsTableAdapter.Fill(shopDBDataSet.Goods);
            }

        }

        private void txtGoodNameSearch_Good_TextChanged(object sender, EventArgs e)
        {
            if (txtGoodNameSearch_Good.TextLength > 0)
            {
                goodsTableAdapter.FillByName(shopDBDataSet.Goods, txtGoodNameSearch_Good.Text);

                if (shopDBDataSet.Goods.Rows.Count > 0)
                {
                    txtGoodIDSearch_Good.Text = shopDBDataSet.Goods.Rows[0]["GoodsID"].ToString();
                    txtGoodID_Good.Text = shopDBDataSet.Goods.Rows[0]["GoodsID"].ToString();
                    txtGoodName_Good.Text = shopDBDataSet.Goods.Rows[0]["GoodsName"].ToString();
                    txtGoodUnitPrice_Good.Text = shopDBDataSet.Goods.Rows[0]["GoodsUnitPrice"].ToString();
                    txtGoodStocks_Good.Text = shopDBDataSet.Goods.Rows[0]["GoodsStock"].ToString();
                }
            }
            else
            {
                txtGoodIDSearch_Good.Clear();
                goodsTableAdapter.Fill(shopDBDataSet.Goods);
            }

        }

        private void dataGridViewGood_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = dataGridViewGood.CurrentCell.RowIndex;
            txtGoodID_Good.Text = dataGridViewGood.Rows[index].Cells[0].Value.ToString();
            txtGoodName_Good.Text = dataGridViewGood.Rows[index].Cells[1].Value.ToString();
            txtGoodUnitPrice_Good.Text = dataGridViewGood.Rows[index].Cells[2].Value.ToString();
            txtGoodStocks_Good.Text = dataGridViewGood.Rows[index].Cells[3].Value.ToString();
        }

        private void btnInsertGood_Good_Click(object sender, EventArgs e)
        {
            if (txtGoodName_Good.TextLength > 0 && txtGoodUnitPrice_Good.TextLength > 0 && txtGoodStocks_Good.TextLength > 0)
            {
                try
                {
                    goodsTableAdapter.InsertQuery(txtGoodName_Good.Text, int.Parse(txtGoodUnitPrice_Good.Text), int.Parse(txtGoodStocks_Good.Text));
                    goodsTableAdapter.Fill(shopDBDataSet.Goods);
                    txtGoodID_Good.Clear();
                    txtGoodName_Good.Clear();
                    txtGoodUnitPrice_Good.Clear();
                    txtGoodStocks_Good.Clear();
                }
                catch
                {
                    MessageBox.Show("نوع فیلد موجودی و قیمت کالا باید عدد باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtGoodUnitPrice_Good.Clear();
                    txtGoodStocks_Good.Clear();
                }
            }
            else
                MessageBox.Show("همه ی فیلد ها پر نشده است", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);


        }

        private void btnUpdateGood_Good_Click(object sender, EventArgs e)
        {
            if (txtGoodID_Good.TextLength > 0)
            {
                try
                {
                    int goodId = int.Parse(txtGoodID_Good.Text);

                    goodsTableAdapter.FillByID(shopDBDataSet.Goods, goodId);

                    string goodName = shopDBDataSet.Goods.Rows[0]["GoodsName"].ToString();
                    int goodPrice = int.Parse(shopDBDataSet.Goods.Rows[0]["GoodsUnitPrice"].ToString());
                    int goodStock = int.Parse(shopDBDataSet.Goods.Rows[0]["GoodsStock"].ToString());

                    if (txtGoodName_Good.TextLength > 0)
                        goodName = txtGoodName_Good.Text;

                    if (txtGoodStocks_Good.TextLength > 0)
                        goodStock = int.Parse(txtGoodStocks_Good.Text);

                    if (txtGoodUnitPrice_Good.TextLength > 0)
                        goodPrice = int.Parse(txtGoodUnitPrice_Good.Text);

                    goodsTableAdapter.UpdateQueryAll(goodName, goodPrice, goodStock, goodId);
                    this.goodsTableAdapter.Fill(this.shopDBDataSet.Goods);
                    txtGoodID_Good.Clear();
                    txtGoodName_Good.Clear();
                    txtGoodUnitPrice_Good.Clear();
                    txtGoodStocks_Good.Clear();
                    MessageBox.Show("کالایی با موفقیت ویرایش شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show("نوع فیلد موجودی و قیمت کالا باید عدد باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtGoodUnitPrice_Good.Clear();
                    txtGoodStocks_Good.Clear();
                }
            }
            else
                MessageBox.Show("کالایی برای ویرایش انتخاب نشده است", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabFactors)
            {
                this.registerFactorTableAdapter.Fill(this.shopDBDataSet.RegisterFactor);
                this.goodsTableAdapter.Fill(this.shopDBDataSet.Goods);
                this.customersTableAdapter.Fill(this.shopDBDataSet.Customers);
                this.factorTableAdapter.Fill(this.shopDBDataSet.Factor);

                while (comboCustomerID_Factor.Items.Count > 0)
                {
                    comboCustomerID_Factor.Items.RemoveAt(0);
                }

                for (int i = 0; i < shopDBDataSet.Customers.Rows.Count; i++)
                {
                    var item = shopDBDataSet.Customers.Rows[i]["CustomerID"].ToString();
                    comboCustomerID_Factor.Items.Add(item);
                }
                comboCustomerID_Factor.Text = currentCustomer;

                while (comboGoodID_Factor.Items.Count > 0)
                {
                    comboGoodID_Factor.Items.RemoveAt(0);
                }
                for (int i = 0; i < shopDBDataSet.Goods.Rows.Count; i++)
                {
                    var item = shopDBDataSet.Goods.Rows[i]["GoodsID"].ToString();
                    comboGoodID_Factor.Items.Add(item);
                }
                comboGoodID_Factor.Text = currentGood;
            }

            if (tabControl1.SelectedTab == tabGoods)
            {
                this.goodsTableAdapter.Fill(this.shopDBDataSet.Goods);
            }
            if (tabControl1.SelectedTab == tabCustomers)
            {
                this.customersTableAdapter.Fill(this.shopDBDataSet.Customers);
            }
            if(tabControl1.SelectedTab == tabReports)
            {
                this.logOfGoodsTableAdapter.Fill(this.shopDBDataSet.LogOfGoods);
                this.registerFactorTableAdapter.Fill(this.shopDBDataSet.RegisterFactor);
                this.factorTableAdapter.Fill(this.shopDBDataSet.Factor);
            }
        }

        private void btnClear_Good_Click(object sender, EventArgs e)
        {
            txtGoodID_Good.Clear();
            txtGoodName_Good.Clear();
            txtGoodUnitPrice_Good.Clear();
            txtGoodStocks_Good.Clear();
        }

        private void btnDeleteGood_Good_Click(object sender, EventArgs e)
        {
            this.goodsTableAdapter.Fill(this.shopDBDataSet.Goods);
            if (txtGoodID_Good.TextLength > 0 && shopDBDataSet.Goods.Rows.Count > 0)
            {
                int goodId = int.Parse(txtGoodID_Good.Text);

                goodsTableAdapter.DeleteQuery(goodId);
                this.goodsTableAdapter.Fill(this.shopDBDataSet.Goods);
                txtGoodID_Good.Clear();
                txtGoodName_Good.Clear();
                txtGoodUnitPrice_Good.Clear();
                txtGoodStocks_Good.Clear();
                MessageBox.Show("کالایی با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
                MessageBox.Show("کالایی برای حذف انتخاب نشده است", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        }

        private void btnInsertToGoodTab_Good_Click(object sender, EventArgs e)
        {
            if (txtGoodID_Good.TextLength > 0)
            {
                int goodId = int.Parse(txtGoodID_Good.Text);

                goodsTableAdapter.FillByID(shopDBDataSet.Goods, goodId);

                string goodName = shopDBDataSet.Goods.Rows[0]["GoodsName"].ToString();
                int goodPrice = int.Parse(shopDBDataSet.Goods.Rows[0]["GoodsUnitPrice"].ToString());
                int goodStock = int.Parse(shopDBDataSet.Goods.Rows[0]["GoodsStock"].ToString());

                tabControl1.SelectedTab = tabFactors;
                comboGoodID_Factor.Text = goodId.ToString();

                txtGoodID_Good.Clear();
                txtGoodName_Good.Clear();
                txtGoodUnitPrice_Good.Clear();
                txtGoodStocks_Good.Clear();
            }
            else
                MessageBox.Show("کالایی برای افزودن به برگه خرید انتخاب نشده است", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        }

        private void txtCustomerIDSearch_Customer_TextChanged(object sender, EventArgs e)
        {


        }

        private void txtCustomerLNameSearch_Customer_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnInsertCustomer_Customer_Click(object sender, EventArgs e)
        {
            if (txtCustomerLName_Customer.TextLength > 0 && txtCustomerBirthday_Customer.TextLength > 0)
            {
                try {
                    customersTableAdapter.InsertQuery(txtCustomerFName_Customer.Text, txtCustomerLName_Customer.Text, txtCustomerTel_Customer.Text, txtCustomerBirthday_Customer.Text);
                    customersTableAdapter.Fill(shopDBDataSet.Customers);

                    txtCustomerID_Customer.Clear();
                    txtCustomerFName_Customer.Clear();
                    txtCustomerLName_Customer.Clear();
                    txtCustomerTel_Customer.Clear();
                    txtCustomerBirthday_Customer.Clear();
                }
                catch
                {
                    MessageBox.Show("فیلد تاریخ فرمت درستی ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtCustomerBirthday_Customer.Clear();
                }

            }
            else
                MessageBox.Show("پر کردن فیلد نام خانوادگی  و تاریخ تولد اجباری است", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btnUpdateCustomer_Customer_Click(object sender, EventArgs e)
        {
            if (txtCustomerID_Customer.TextLength > 0)
            {
                try
                {
                    int customerId = int.Parse(txtCustomerID_Customer.Text);

                    customersTableAdapter.FillByID(shopDBDataSet.Customers, customerId);

                    string customerFName = shopDBDataSet.Customers.Rows[0]["CustomerName"].ToString();
                    string customerLName = shopDBDataSet.Customers.Rows[0]["CustomerFamily"].ToString();
                    string customerTel = shopDBDataSet.Customers.Rows[0]["CustomerPhone"].ToString();
                    string customerBirthday = shopDBDataSet.Customers.Rows[0]["CustomerBirthday"].ToString();

                    if (txtCustomerFName_Customer.TextLength > 0)
                        customerFName = txtCustomerFName_Customer.Text;

                    if (txtCustomerLName_Customer.TextLength > 0)
                        customerLName = txtCustomerLName_Customer.Text;

                    if (txtCustomerTel_Customer.TextLength > 0)
                        customerTel = txtCustomerTel_Customer.Text;

                    if (txtCustomerBirthday_Customer.TextLength > 0)
                        customerBirthday = txtCustomerBirthday_Customer.Text;

                    customersTableAdapter.UpdateQuery(customerFName, customerLName, customerTel, customerBirthday, customerId);
                    this.customersTableAdapter.Fill(this.shopDBDataSet.Customers);
                    txtCustomerID_Customer.Clear();
                    txtCustomerLName_Customer.Clear();
                    txtCustomerFName_Customer.Clear();
                    txtCustomerTel_Customer.Clear();
                    txtCustomerBirthday_Customer.Clear();

                    MessageBox.Show("اطلاعات مشتری با موفقیت ویرایش شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                catch
                {
                    MessageBox.Show("فیلد تاریخ فرمت درستی ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtCustomerBirthday_Customer.Clear();
                }
            }
            else
                MessageBox.Show("اطلاعات مشتری برای ویرایش انتخاب نشده است", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btnDeleteCustomer_Customer_Click(object sender, EventArgs e)
        {
            txtCustomerID_Customer.Clear();
            txtCustomerLName_Customer.Clear();
            txtCustomerFName_Customer.Clear();
            txtCustomerTel_Customer.Clear();
            txtCustomerBirthday_Customer.Clear();
        }

        private void btnClear_Customer_Click(object sender, EventArgs e)
        {
            this.customersTableAdapter.Fill(this.shopDBDataSet.Customers);
            if (txtCustomerID_Customer.TextLength > 0 && shopDBDataSet.Customers.Rows.Count > 0)
            {
                int customerId = int.Parse(txtCustomerID_Customer.Text);

                customersTableAdapter.DeleteQuery(customerId);
                this.customersTableAdapter.Fill(this.shopDBDataSet.Customers);
                txtCustomerID_Customer.Clear();
                txtCustomerLName_Customer.Clear();
                txtCustomerFName_Customer.Clear();
                txtCustomerTel_Customer.Clear();
                txtCustomerBirthday_Customer.Clear();
                MessageBox.Show("اطلاعات مشتری با موفقیت حذف شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
                MessageBox.Show("اطلاعات مشتری برای حذف انتخاب نشده است", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void txtDiscount_Factor_TextChanged(object sender, EventArgs e)
        {
            int allAmount = 0;
            try
            {
                 allAmount = int.Parse(lblAmount_Factor.Text);
            }
            catch
            {
                MessageBox.Show("ابتدا محصولی در سبد خرید درج کنید", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtDiscount_Factor.Clear();
            }
            if (txtDiscount_Factor.TextLength > 0)
            {
                try
                {
                    int discount = int.Parse(txtDiscount_Factor.Text);
                    if (discount >= 1 && discount <= 100)
                    {
                        int price = allAmount - ((allAmount * discount) / 100);
                        lblAmountAfter_Factor.Text = price.ToString();
                    }
                    else {
                        txtDiscount_Factor.Clear();
                        MessageBox.Show("رنج تخفیف بین 1 تا 100 درصد است", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    
                }
                catch
                {
                    MessageBox.Show("فیلد تعداد باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtDiscount_Factor.Clear();
                }

            }

        }

        private void btnInsertToFactorTab_Customer_Click(object sender, EventArgs e)
        {
            if (txtCustomerID_Customer.TextLength > 0)
            {
                int customerId = int.Parse(txtCustomerID_Customer.Text);

                customersTableAdapter.FillByID(shopDBDataSet.Customers, customerId);

                string customerName = shopDBDataSet.Customers.Rows[0]["CustomerName"].ToString() + "  " + shopDBDataSet.Customers.Rows[0]["CustomerFamily"].ToString();
                string customerTel = shopDBDataSet.Customers.Rows[0]["CustomerPhone"].ToString();

                tabControl1.SelectedTab = tabFactors;
                comboCustomerID_Factor.Text = customerId.ToString();

                txtCustomerID_Customer.Clear();
                txtCustomerLName_Customer.Clear();
                txtCustomerFName_Customer.Clear();
                txtCustomerTel_Customer.Clear();
                txtCustomerBirthday_Customer.Clear();
            }
            else
                MessageBox.Show("اطلاعات مشتری برای افزودن به برگه خرید انتخاب نشده است", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void txtIDSearch_Customer_TextChanged(object sender, EventArgs e)
        {
            if (txtIDSearch_Customer.TextLength > 0)
            {
                try
                {
                    customersTableAdapter.FillByID(shopDBDataSet.Customers, int.Parse(txtIDSearch_Customer.Text));
                    if (shopDBDataSet.Customers.Rows.Count > 0)
                    {
                        txtNameSearch_Customer.Text = shopDBDataSet.Customers.Rows[0]["CustomerFamily"].ToString();
                        txtCustomerFName_Customer.Text = shopDBDataSet.Customers.Rows[0]["CustomerName"].ToString();
                        txtCustomerLName_Customer.Text = shopDBDataSet.Customers.Rows[0]["CustomerFamily"].ToString();
                        txtCustomerTel_Customer.Text = shopDBDataSet.Customers.Rows[0]["CustomerPhone"].ToString();
                        txtCustomerBirthday_Customer.Text = shopDBDataSet.Customers.Rows[0]["CustomerBirthday"].ToString();
                    }
                    else
                    {
                        txtCustomerID_Customer.Clear();
                        txtCustomerLName_Customer.Clear();
                        txtCustomerFName_Customer.Clear();
                        txtCustomerTel_Customer.Clear();
                        txtCustomerBirthday_Customer.Clear();
                    }
                }
                catch
                {
                    MessageBox.Show("فیلد کد مشتری باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtIDSearch_Customer.Clear();
                }
            }
            else
            {
                txtNameSearch_Customer.Clear();
                customersTableAdapter.Fill(shopDBDataSet.Customers);
            }
        }

        private void txtNameSearch_Customer_TextChanged(object sender, EventArgs e)
        {
            if (txtNameSearch_Customer.TextLength > 0)
            {
                customersTableAdapter.FillByLName(shopDBDataSet.Customers, txtNameSearch_Customer.Text);

                if (shopDBDataSet.Customers.Rows.Count > 0)
                {
                    txtCustomerID_Customer.Text = shopDBDataSet.Customers.Rows[0]["CustomerID"].ToString();
                    txtCustomerFName_Customer.Text = shopDBDataSet.Customers.Rows[0]["CustomerName"].ToString();
                    txtCustomerLName_Customer.Text = shopDBDataSet.Customers.Rows[0]["CustomerFamily"].ToString();
                    txtCustomerTel_Customer.Text = shopDBDataSet.Customers.Rows[0]["CustomerPhone"].ToString();
                    txtCustomerBirthday_Customer.Text = shopDBDataSet.Customers.Rows[0]["CustomerBirthday"].ToString();
                }
                else
                {
                    txtCustomerID_Customer.Clear();
                    txtCustomerLName_Customer.Clear();
                    txtCustomerFName_Customer.Clear();
                    txtCustomerTel_Customer.Clear();
                    txtCustomerBirthday_Customer.Clear();
                }
            }
            else
            {
                txtCustomerID_Customer.Clear();
                customersTableAdapter.Fill(shopDBDataSet.Customers);
            }
        }

        private void btnSearchDateFactorTable_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void tabControl2_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (tabControl2.SelectedTab == tabLog)
            {
                this.logOfGoodsTableAdapter.Fill(this.shopDBDataSet.LogOfGoods);
            }
            if (tabControl2.SelectedTab == tabFactorTable)
            {
                this.factorTableAdapter.Fill(this.shopDBDataSet.Factor);
            }
            if (tabControl2.SelectedTab == tabRegisterFactor)
            {
                this.registerFactorTableAdapter.Fill(this.shopDBDataSet.RegisterFactor);
            }



        }

        private void comboGoodIdLog_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void txtGoodIdLog_TextChanged(object sender, EventArgs e)
        {
            if (txtGoodIdLog.TextLength>0)
            {
                try
                {
                    this.logOfGoodsTableAdapter.FillByGoodId(shopDBDataSet.LogOfGoods, int.Parse(txtGoodIdLog.Text));
                    if (shopDBDataSet.LogOfGoods.Rows.Count > 0)
                    {
                        txtGoodNameLog.Text = shopDBDataSet.LogOfGoods.Rows[0]["nameOfGood"].ToString();
                    }
                }
                 catch
                {
                    MessageBox.Show("فیلد کد کالا باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtGoodIdLog.Clear();
                }
            }
            else
            {
                this.logOfGoodsTableAdapter.Fill(this.shopDBDataSet.LogOfGoods);
                txtGoodNameLog.Clear();
            }
        }

        private void txtGoodNameLog_TextChanged(object sender, EventArgs e)
        {
            if (txtGoodNameLog.TextLength > 0)
            {
                this.logOfGoodsTableAdapter.FillByGoodName(shopDBDataSet.LogOfGoods, txtGoodNameLog.Text);
            }
            else
            {
                this.logOfGoodsTableAdapter.Fill(this.shopDBDataSet.LogOfGoods);
                txtGoodIdLog.Clear();
            }
        }

        private void comboActionTypeLog_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboActionTypeLog.Text.Length > 0)
            {
                this.logOfGoodsTableAdapter.FillByAction(shopDBDataSet.LogOfGoods, comboActionTypeLog.Text);
            }
            else
            {
                this.logOfGoodsTableAdapter.Fill(this.shopDBDataSet.LogOfGoods);
                comboActionTypeLog.ResetText();
            }
        }

        private void btnSearchDateLog_Click(object sender, EventArgs e)
        {
            if (txtDateStartLog.TextLength > 0 && txtDateEndLog.TextLength>0)
            {
                try
                {
                    this.logOfGoodsTableAdapter.FillByDate(shopDBDataSet.LogOfGoods, txtDateStartLog.Text, txtDateEndLog.Text);
                }
                catch
                {
                    MessageBox.Show("فیلد تاریخ فرمت درستی ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtDateStartLog.Clear();
                    txtDateEndLog.Clear();
                }
            }
            else
            {
                this.logOfGoodsTableAdapter.Fill(this.shopDBDataSet.LogOfGoods);
                MessageBox.Show("حداقل و حداکثر تاریخ را معلوم نمایید", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void btnSearchAllLog_Click(object sender, EventArgs e)
        {
            if(txtGoodIdLog.TextLength>0 && comboActionTypeLog.Text.Length>0 && txtDateStartLog.TextLength > 0 && txtDateEndLog.TextLength > 0)
            {
                try
                {
                    this.logOfGoodsTableAdapter.FillByAll(shopDBDataSet.LogOfGoods, comboActionTypeLog.Text, txtDateStartLog.Text, txtDateEndLog.Text, int.Parse(txtGoodIdLog.Text));
                }
                catch
                {
                    MessageBox.Show("فیلد تاریخ فرمت درستی ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtDateStartLog.Clear();
                    txtDateEndLog.Clear();
                }
            }

            if(comboActionTypeLog.Text.Length > 0 && txtGoodNameLog.TextLength > 0)//Name Action
            {
                this.logOfGoodsTableAdapter.FillByNameAction(shopDBDataSet.LogOfGoods,txtGoodNameLog.Text, comboActionTypeLog.Text);
            }

            if (txtGoodNameLog.TextLength > 0 && txtDateStartLog.TextLength > 0 && txtDateEndLog.TextLength > 0)//Nam eDate
            {
                try
                {
                    this.logOfGoodsTableAdapter.FillByNameDate(shopDBDataSet.LogOfGoods, txtGoodNameLog.Text, txtDateStartLog.Text, txtDateEndLog.Text);
                }
                catch
                {
                    MessageBox.Show("فیلد تاریخ فرمت درستی ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtDateStartLog.Clear();
                    txtDateEndLog.Clear();
                }
            }
            if (comboActionTypeLog.Text.Length > 0 && txtDateStartLog.TextLength > 0 && txtDateEndLog.TextLength > 0)//Action Date
            {
                try
                {
                    this.logOfGoodsTableAdapter.FillByActionDate(shopDBDataSet.LogOfGoods, comboActionTypeLog.Text, txtDateStartLog.Text, txtDateEndLog.Text);
                }
                catch
                {
                    MessageBox.Show("فیلد تاریخ فرمت درستی ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtDateStartLog.Clear();
                    txtDateEndLog.Clear();
                }
            }

            if (txtGoodNameLog.TextLength > 0 && comboActionTypeLog.Text.Length > 0 && txtDateStartLog.TextLength > 0 && txtDateEndLog.TextLength > 0)
            {
                try
                {
                    this.logOfGoodsTableAdapter.FillByAll2(shopDBDataSet.LogOfGoods, comboActionTypeLog.Text, txtDateStartLog.Text, txtDateEndLog.Text, txtGoodNameLog.Text);
                }
                catch
                {
                    MessageBox.Show("فیلد تاریخ فرمت درستی ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtDateStartLog.Clear();
                    txtDateEndLog.Clear();
                }
            }
        }

        private void btnClearLog_Click(object sender, EventArgs e)
        {
            txtGoodIdLog.Clear();
            txtGoodNameLog.Clear();
            comboActionTypeLog.ResetText();
            txtDateStartLog.Clear();
            txtDateEndLog.Clear();
            this.logOfGoodsTableAdapter.Fill(this.shopDBDataSet.LogOfGoods);

        }

        private void txtFactorIdFactorTable_TextChanged(object sender, EventArgs e)
        {
            if (txtFactorIdFactorTable.TextLength > 0)
            {
                try
                {
                    factorTableAdapter.FillByFactorId(shopDBDataSet.Factor, int.Parse(txtFactorIdFactorTable.Text));
                }
                catch
                {
                    MessageBox.Show("فیلد کد فاکتور باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtFactorIdFactorTable.Clear();
                }
            }
            else
            {
                factorTableAdapter.Fill(shopDBDataSet.Factor);
            }
        }

        private void btnClearFactorTable_Click(object sender, EventArgs e)
        {
            txtFactorIdFactorTable.Clear();
            txtCustomerIdFactorTable.Clear();
            txtDateStartFactorTable.Clear();
            txtDateEndFactorTable.Clear();
            factorTableAdapter.Fill(shopDBDataSet.Factor);
        }

        private void txtCustomerIdFactorTable_TextChanged(object sender, EventArgs e)
        {
            if (txtCustomerIdFactorTable.TextLength > 0)
            {
                try
                {
                    factorTableAdapter.FillByCustomerId(shopDBDataSet.Factor, int.Parse(txtCustomerIdFactorTable.Text));
                }
                catch
                {
                    MessageBox.Show("فیلد کد مشتری باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtCustomerIdFactorTable.Clear();
                }
            }
            else
            {
                factorTableAdapter.Fill(shopDBDataSet.Factor);
            }
        }

        private void btnSearchDateFactorTable_Click(object sender, EventArgs e)
        {
            if (txtDateStartFactorTable.TextLength > 0 && txtDateEndFactorTable.TextLength > 0)
            {
                try
                {
                    factorTableAdapter.FillByDate(shopDBDataSet.Factor, txtDateStartFactorTable.Text, txtDateEndFactorTable.Text);
                }
                catch
                {
                    MessageBox.Show("فیلد تاریخ فرمت درستی ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtDateStartFactorTable.Clear();
                    txtDateEndFactorTable.Clear();
                }
            }
            else
            {
                factorTableAdapter.Fill(shopDBDataSet.Factor);
                MessageBox.Show("حداقل و حداکثر تاریخ را معلوم نمایید", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void btnSearchAllFactorTable_Click(object sender, EventArgs e)
        {
            if(txtFactorIdFactorTable.TextLength > 0 && txtCustomerIdFactorTable.TextLength > 0)//FactorId CustomerId
            {
                factorTableAdapter.FillByFactorCustomer(shopDBDataSet.Factor, int.Parse(txtCustomerIdFactorTable.Text), int.Parse(txtCustomerIdFactorTable.Text));
            }

            if (txtFactorIdFactorTable.TextLength > 0 && txtDateStartFactorTable.TextLength > 0 && txtDateEndFactorTable.TextLength > 0)//FactorId Date
            {
                try
                {
                    factorTableAdapter.FillByFactorIdDate(shopDBDataSet.Factor, int.Parse(txtFactorIdFactorTable.Text), txtDateStartFactorTable.Text, txtDateEndFactorTable.Text);

                }
                catch
                {
                    MessageBox.Show("فیلد تاریخ فرمت درستی ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtDateStartFactorTable.Clear();
                    txtDateEndFactorTable.Clear();
                }
            }

            if(txtCustomerIdFactorTable.TextLength > 0 && txtDateStartFactorTable.TextLength > 0 && txtDateEndFactorTable.TextLength > 0)//CustomerIdDate
            {
                try
                {
                    factorTableAdapter.FillByFactorIdDate(shopDBDataSet.Factor, int.Parse(txtCustomerIdFactorTable.Text), txtDateStartFactorTable.Text, txtDateEndFactorTable.Text);
                }
                catch
                {
                    MessageBox.Show("فیلد تاریخ فرمت درستی ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtDateStartFactorTable.Clear();
                    txtDateEndFactorTable.Clear();
                }
            }

            if(txtCustomerIdFactorTable.TextLength > 0 && txtFactorIdFactorTable.TextLength > 0 && txtDateStartFactorTable.TextLength > 0 && txtDateEndFactorTable.TextLength > 0)//All
            {
                try
                {
                    factorTableAdapter.FillByAll(shopDBDataSet.Factor, int.Parse(txtFactorIdFactorTable.Text), int.Parse(txtCustomerIdFactorTable.Text), txtDateStartFactorTable.Text, txtDateEndFactorTable.Text);
                }
                catch
                {
                    MessageBox.Show("فیلد تاریخ فرمت درستی ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtDateStartFactorTable.Clear();
                    txtDateEndFactorTable.Clear();
                }
            }
        }

        private void txtFavtorIdRegisterTable_TextChanged(object sender, EventArgs e)
        {
            if (txtFavtorIdRegisterTable.TextLength > 0)
            {
                try
                {
                    registerFactorTableAdapter.FillByFactorID(shopDBDataSet.RegisterFactor, int.Parse(txtFavtorIdRegisterTable.Text));
                }
                catch
                {
                    MessageBox.Show("فیلد کد فاکتور باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtFavtorIdRegisterTable.Clear();
                }
            }
            else
            {
                registerFactorTableAdapter.Fill(shopDBDataSet.RegisterFactor);
            }
        }

        private void txtGoodIdRegisterTable_TextChanged(object sender, EventArgs e)
        {
            if (txtGoodIdRegisterTable.TextLength > 0)
            {
                try
                {
                    registerFactorTableAdapter.FillByGoodsID(shopDBDataSet.RegisterFactor, int.Parse(txtGoodIdRegisterTable.Text));
                }
                catch
                {
                    MessageBox.Show("فیلد کد کالا باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtGoodIdRegisterTable.Clear();
                }
            }
            else
            {
                registerFactorTableAdapter.Fill(shopDBDataSet.RegisterFactor);
            }
        }

        private void btnClearRegisterTable_Click(object sender, EventArgs e)
        {
            txtFavtorIdRegisterTable.Clear();
            txtGoodIdRegisterTable.Clear();
            txtStartOffRegisterTable.Clear();
            txtEndOffRegisterTable.Clear();
            registerFactorTableAdapter.Fill(shopDBDataSet.RegisterFactor);

        }

        private void txtStartOffRegisterTable_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSearchOffRegisterTable_Click(object sender, EventArgs e)
        {
            if (txtStartOffRegisterTable.TextLength>0 && txtEndOffRegisterTable.TextLength > 0)
            {
                try
                {
                    registerFactorTableAdapter.FillByDiscount(shopDBDataSet.RegisterFactor, int.Parse(txtStartOffRegisterTable.Text), int.Parse(txtEndOffRegisterTable.Text));
                }
                catch
                {
                    MessageBox.Show("فیلد تخفیف باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtStartOffRegisterTable.Clear();
                    txtEndOffRegisterTable.Clear();
                }
            }
            else
            {
                registerFactorTableAdapter.Fill(shopDBDataSet.RegisterFactor);
            }
        }

        private void btnSearchAllRegisterTable_Click(object sender, EventArgs e)
        {
            if(txtFavtorIdRegisterTable.TextLength>0 && txtGoodIdRegisterTable.TextLength>0)//FactorID GoodID
            {
                registerFactorTableAdapter.FillByFactorIDGoodID(shopDBDataSet.RegisterFactor, int.Parse(txtFavtorIdRegisterTable.Text), int.Parse(txtGoodIdRegisterTable.Text));
            }

            if (txtFavtorIdRegisterTable.TextLength > 0 && txtStartOffRegisterTable.TextLength > 0 && txtEndOffRegisterTable.TextLength > 0)//FactorID Discount
            {
                try
                {
                    registerFactorTableAdapter.FillByFactorIDDiscount(shopDBDataSet.RegisterFactor, int.Parse(txtFavtorIdRegisterTable.Text), int.Parse(txtStartOffRegisterTable.Text), int.Parse(txtEndOffRegisterTable.Text));
                }
                catch
                {
                    MessageBox.Show("فیلد تخفیف باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtStartOffRegisterTable.Clear();
                    txtEndOffRegisterTable.Clear();
                }
            }

            if (txtGoodIdRegisterTable.TextLength > 0 && txtStartOffRegisterTable.TextLength > 0 && txtEndOffRegisterTable.TextLength > 0)//GoodID Discount
            {
                try
                {
                    registerFactorTableAdapter.FillByFactorIDDiscount(shopDBDataSet.RegisterFactor, int.Parse(txtGoodIdRegisterTable.Text), int.Parse(txtStartOffRegisterTable.Text), int.Parse(txtEndOffRegisterTable.Text));
                }
                catch
                {
                    MessageBox.Show("فیلد تخفیف باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtStartOffRegisterTable.Clear();
                    txtEndOffRegisterTable.Clear();
                }
            }

            if (txtFavtorIdRegisterTable.TextLength > 0 && txtGoodIdRegisterTable.TextLength > 0 && txtStartOffRegisterTable.TextLength > 0 && txtEndOffRegisterTable.TextLength > 0)//All
            {
                try
                {
                    registerFactorTableAdapter.FillByAll(shopDBDataSet.RegisterFactor, int.Parse(txtFavtorIdRegisterTable.Text), int.Parse(txtGoodIdRegisterTable.Text), int.Parse(txtStartOffRegisterTable.Text), int.Parse(txtEndOffRegisterTable.Text));
                }
                catch
                {
                    MessageBox.Show("فیلد تخفیف باید با عدد پر شود", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    txtStartOffRegisterTable.Clear();
                    txtEndOffRegisterTable.Clear();
                }
            }
        }

        private void txtCustomerBirthday_Customer_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridViewCustomers_Customer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = dataGridViewCustomers_Customer.CurrentCell.RowIndex;
            txtCustomerID_Customer.Text = dataGridViewCustomers_Customer.Rows[index].Cells[0].Value.ToString();
            txtCustomerFName_Customer.Text = dataGridViewCustomers_Customer.Rows[index].Cells[1].Value.ToString();
            txtCustomerLName_Customer.Text = dataGridViewCustomers_Customer.Rows[index].Cells[2].Value.ToString();
            txtCustomerTel_Customer.Text = dataGridViewCustomers_Customer.Rows[index].Cells[3].Value.ToString();
            txtCustomerBirthday_Customer.Text = dataGridViewCustomers_Customer.Rows[index].Cells[4].Value.ToString();
        }
    }
}
