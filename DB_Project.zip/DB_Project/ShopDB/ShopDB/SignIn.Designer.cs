﻿namespace ShopDB
{
    partial class SignIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblGoToSignUp = new System.Windows.Forms.Label();
            this.picStatePassSignIn = new System.Windows.Forms.PictureBox();
            this.btnExitSignIn = new System.Windows.Forms.Button();
            this.lblPassSignIn = new System.Windows.Forms.Label();
            this.lblUserNameSignIn = new System.Windows.Forms.Label();
            this.txtPassSignIn = new System.Windows.Forms.TextBox();
            this.txtUsernameSignIn = new System.Windows.Forms.TextBox();
            this.picBackgrounfSignIn = new System.Windows.Forms.PictureBox();
            this.btnSignIn = new System.Windows.Forms.Button();
            this.shopDBDataSet = new ShopDB.ShopDBDataSet();
            this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.usersTableAdapter = new ShopDB.ShopDBDataSetTableAdapters.UsersTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.picStatePassSignIn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBackgrounfSignIn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lblGoToSignUp
            // 
            this.lblGoToSignUp.AutoSize = true;
            this.lblGoToSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblGoToSignUp.Font = new System.Drawing.Font("B Yekan", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblGoToSignUp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblGoToSignUp.Location = new System.Drawing.Point(253, 322);
            this.lblGoToSignUp.Name = "lblGoToSignUp";
            this.lblGoToSignUp.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblGoToSignUp.Size = new System.Drawing.Size(296, 20);
            this.lblGoToSignUp.TabIndex = 17;
            this.lblGoToSignUp.Text = "در صورت نداشتن اکانت برای ساخت اکانت اینجا کلیک کنید.";
            this.lblGoToSignUp.Click += new System.EventHandler(this.lblGoToSignUp_Click);
            this.lblGoToSignUp.DragOver += new System.Windows.Forms.DragEventHandler(this.lblGoToSignUp_DragOver);
            // 
            // picStatePassSignIn
            // 
            this.picStatePassSignIn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.picStatePassSignIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picStatePassSignIn.Image = global::ShopDB.Properties.Resources.hidePass;
            this.picStatePassSignIn.Location = new System.Drawing.Point(243, 293);
            this.picStatePassSignIn.Name = "picStatePassSignIn";
            this.picStatePassSignIn.Size = new System.Drawing.Size(26, 17);
            this.picStatePassSignIn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picStatePassSignIn.TabIndex = 16;
            this.picStatePassSignIn.TabStop = false;
            this.picStatePassSignIn.Click += new System.EventHandler(this.picStatePassSignIn_Click);
            // 
            // btnExitSignIn
            // 
            this.btnExitSignIn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnExitSignIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExitSignIn.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnExitSignIn.ForeColor = System.Drawing.Color.White;
            this.btnExitSignIn.Location = new System.Drawing.Point(238, 359);
            this.btnExitSignIn.Name = "btnExitSignIn";
            this.btnExitSignIn.Size = new System.Drawing.Size(114, 36);
            this.btnExitSignIn.TabIndex = 15;
            this.btnExitSignIn.Text = "خروج";
            this.btnExitSignIn.UseVisualStyleBackColor = false;
            this.btnExitSignIn.Click += new System.EventHandler(this.btnExitSignIn_Click);
            // 
            // lblPassSignIn
            // 
            this.lblPassSignIn.AutoSize = true;
            this.lblPassSignIn.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblPassSignIn.Location = new System.Drawing.Point(481, 251);
            this.lblPassSignIn.Name = "lblPassSignIn";
            this.lblPassSignIn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblPassSignIn.Size = new System.Drawing.Size(72, 29);
            this.lblPassSignIn.TabIndex = 13;
            this.lblPassSignIn.Text = "رمز عبور";
            // 
            // lblUserNameSignIn
            // 
            this.lblUserNameSignIn.AutoSize = true;
            this.lblUserNameSignIn.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblUserNameSignIn.Location = new System.Drawing.Point(472, 163);
            this.lblUserNameSignIn.Name = "lblUserNameSignIn";
            this.lblUserNameSignIn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblUserNameSignIn.Size = new System.Drawing.Size(82, 29);
            this.lblUserNameSignIn.TabIndex = 12;
            this.lblUserNameSignIn.Text = "نام کاربری";
            // 
            // txtPassSignIn
            // 
            this.txtPassSignIn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtPassSignIn.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtPassSignIn.Location = new System.Drawing.Point(238, 283);
            this.txtPassSignIn.Name = "txtPassSignIn";
            this.txtPassSignIn.PasswordChar = '*';
            this.txtPassSignIn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtPassSignIn.Size = new System.Drawing.Size(318, 36);
            this.txtPassSignIn.TabIndex = 11;
            // 
            // txtUsernameSignIn
            // 
            this.txtUsernameSignIn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtUsernameSignIn.Font = new System.Drawing.Font("B Yekan", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtUsernameSignIn.Location = new System.Drawing.Point(238, 195);
            this.txtUsernameSignIn.Name = "txtUsernameSignIn";
            this.txtUsernameSignIn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtUsernameSignIn.Size = new System.Drawing.Size(318, 36);
            this.txtUsernameSignIn.TabIndex = 10;
            // 
            // picBackgrounfSignIn
            // 
            this.picBackgrounfSignIn.BackColor = System.Drawing.Color.Transparent;
            this.picBackgrounfSignIn.Image = global::ShopDB.Properties.Resources._2;
            this.picBackgrounfSignIn.Location = new System.Drawing.Point(156, 68);
            this.picBackgrounfSignIn.Name = "picBackgrounfSignIn";
            this.picBackgrounfSignIn.Size = new System.Drawing.Size(489, 354);
            this.picBackgrounfSignIn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBackgrounfSignIn.TabIndex = 9;
            this.picBackgrounfSignIn.TabStop = false;
            // 
            // btnSignIn
            // 
            this.btnSignIn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSignIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSignIn.Font = new System.Drawing.Font("B Yekan", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSignIn.ForeColor = System.Drawing.Color.White;
            this.btnSignIn.Location = new System.Drawing.Point(442, 359);
            this.btnSignIn.Name = "btnSignIn";
            this.btnSignIn.Size = new System.Drawing.Size(114, 36);
            this.btnSignIn.TabIndex = 14;
            this.btnSignIn.Text = "ورود";
            this.btnSignIn.UseVisualStyleBackColor = false;
            this.btnSignIn.Click += new System.EventHandler(this.btnSignIn_Click);
            // 
            // shopDBDataSet
            // 
            this.shopDBDataSet.DataSetName = "ShopDBDataSet";
            this.shopDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // usersBindingSource
            // 
            this.usersBindingSource.DataMember = "Users";
            this.usersBindingSource.DataSource = this.shopDBDataSet;
            // 
            // usersTableAdapter
            // 
            this.usersTableAdapter.ClearBeforeFill = true;
            // 
            // SignIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackgroundImage = global::ShopDB.Properties.Resources._1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 500);
            this.ControlBox = false;
            this.Controls.Add(this.lblGoToSignUp);
            this.Controls.Add(this.picStatePassSignIn);
            this.Controls.Add(this.btnExitSignIn);
            this.Controls.Add(this.btnSignIn);
            this.Controls.Add(this.lblPassSignIn);
            this.Controls.Add(this.lblUserNameSignIn);
            this.Controls.Add(this.txtPassSignIn);
            this.Controls.Add(this.txtUsernameSignIn);
            this.Controls.Add(this.picBackgrounfSignIn);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SignIn";
            this.Text = "SignIn";
            this.Load += new System.EventHandler(this.SignIn_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picStatePassSignIn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBackgrounfSignIn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblGoToSignUp;
        private System.Windows.Forms.PictureBox picStatePassSignIn;
        private System.Windows.Forms.Button btnExitSignIn;
        private System.Windows.Forms.Label lblPassSignIn;
        private System.Windows.Forms.Label lblUserNameSignIn;
        private System.Windows.Forms.TextBox txtPassSignIn;
        private System.Windows.Forms.TextBox txtUsernameSignIn;
        private System.Windows.Forms.PictureBox picBackgrounfSignIn;
        private System.Windows.Forms.Button btnSignIn;
        private ShopDBDataSet shopDBDataSet;
        private System.Windows.Forms.BindingSource usersBindingSource;
        private ShopDBDataSetTableAdapters.UsersTableAdapter usersTableAdapter;
    }
}

